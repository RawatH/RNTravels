package app.mg.merkur.com.mgapp.component.ui.fragment;

import android.os.Bundle;
import android.support.annotation.Nullable;
import android.view.GestureDetector;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.webkit.WebChromeClient;
import android.webkit.WebView;
import android.webkit.WebViewClient;

import app.mg.merkur.com.mgapp.R;
import app.mg.merkur.com.mgapp.network.NetworkConst;
import app.mg.merkur.com.mgapp.util.Util;

/**
 * Created by hrawat on 17-01-2018.
 */

public class ProductFragment extends BaseFragment {

    private WebView webView;
    private GestureDetector gestureDetector;

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {

        View view = inflater.inflate(R.layout.fragment_product, container, false);
        initView(view);

        return view;
    }


    private void initView(View view) {
        webView = view.findViewById(R.id.productWv);
        webView.getSettings().setJavaScriptEnabled(true);
//            gestureDetector = new GestureDetector(context, new MGGestureListener());
//            webView.setOnTouchListener(new View.OnTouchListener() {
//                @Override
//                public boolean onTouch(View v, MotionEvent event) {
//                    return gestureDetector.onTouchEvent(event);
//                }
//
//            });

        webView.loadUrl(NetworkConst.PRODUCT_URL);
        showProgress("Loading...");
        webView.setWebViewClient(new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(WebView view, String url) {
                view.loadUrl(url);
                showProgress("Loading...");
                return true;
            }
        });

        webView.setWebChromeClient(new WebChromeClient() {
            @Override
            public void onProgressChanged(WebView view, int newProgress) {
                if (newProgress == 100) {
                    dismissProgress();
                }
                super.onProgressChanged(view, newProgress);
            }
        });
    }

    @Override
    public void onResume() {
        super.onResume();
        setTitle(getResources().getString(R.string.meet_the_product));
        listener.updateToolbarTitle();
    }

    //GESTURE

    class MGGestureListener extends GestureDetector.SimpleOnGestureListener {

        private static final int SWIPE_THRESHOLD = 100;
        private static final int SWIPE_VELOCITY_THRESHOLD = 100;

        @Override
        public boolean onDown(MotionEvent event) {
            return true;
        }

        @Override
        public boolean onFling(MotionEvent e1, MotionEvent e2, float velocityX, float velocityY) {
            boolean result = false;
            try {
                float diffY = e2.getY() - e1.getY();
                float diffX = e2.getX() - e1.getX();
                if (Math.abs(diffX) > Math.abs(diffY)) {
                    if (Math.abs(diffX) > SWIPE_THRESHOLD && Math.abs(velocityX) > SWIPE_VELOCITY_THRESHOLD) {
                        if (diffX > 0) {
                            onSwipeRight();
                        } else {
                            onSwipeLeft();
                        }
                        result = true;
                    }
                }
            } catch (Exception exception) {
                exception.printStackTrace();
            }
            return result;
        }

        public void onSwipeRight() {
            Util.toast(context, "Right swipe");
            if (webView.canGoBack()) {
                webView.goBack();
            }
        }

        public void onSwipeLeft() {
            Util.toast(context, "Left swipe");
        }
    }


}


