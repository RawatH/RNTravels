package app.mg.merkur.com.mgapp.util;

import android.app.Activity;
import android.app.ActivityManager;
import android.content.Context;
import android.content.Intent;
import android.content.pm.ActivityInfo;
import android.content.res.Configuration;
import android.os.Bundle;
import android.util.Base64;
import android.util.DisplayMetrics;
import android.util.Log;
import android.util.Xml;
import android.view.Gravity;
import android.view.View;
import android.widget.ImageView;
import android.widget.Toast;

import com.bumptech.glide.Glide;

import org.xmlpull.v1.XmlPullParser;
import org.xmlpull.v1.XmlPullParserException;

import java.io.BufferedInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;
import java.util.zip.ZipEntry;
import java.util.zip.ZipInputStream;

import app.mg.merkur.com.mgapp.component.ui.service.DownloadService;
import app.mg.merkur.com.mgapp.db.database.MGAppDatabse;
import app.mg.merkur.com.mgapp.manager.AppController;
import app.mg.merkur.com.mgapp.models.catalog.CabinetVO;
import app.mg.merkur.com.mgapp.models.catalog.CatalogVO;
import app.mg.merkur.com.mgapp.models.catalog.CategoryVO;
import app.mg.merkur.com.mgapp.models.catalog.GameVO;
import app.mg.merkur.com.mgapp.models.catalog.SuiteVO;
import app.mg.merkur.com.mgapp.models.catalog.TagVO;
import app.mg.merkur.com.mgapp.models.catalog.TeamVO;
import app.mg.merkur.com.mgapp.models.download.DownloadInfoVO;
import app.mg.merkur.com.mgapp.models.floorplan.FloorLocationVO;
import app.mg.merkur.com.mgapp.models.floorplan.FloorObj;
import app.mg.merkur.com.mgapp.models.floorplan.FloorVO;
import app.mg.merkur.com.mgapp.network.NetworkConst;

/**
 * Created by hrawat on 17-01-2018.
 */

public class Util {

    public static String getZipFilePath(Context ctx) {
        return ctx.getFilesDir() + File.separator + "config";
    }

    public static void toast(Context ctx, String msg) {
        Toast toast = Toast.makeText(ctx, msg, Toast.LENGTH_SHORT);
        toast.setGravity(Gravity.CENTER, 0, 0);
        toast.show();
    }

    public static boolean isUpdateAvailable(MGAppDatabse db, DownloadInfoVO serverDownloadInfoVO) {
        DownloadInfoVO dbDownloadInfoVO = db.getDownloadDao().getDownloadingVO(MGConstants.DownloadStatus.DOWNLOADED);
        //TODO : Just to force the update scenario . Remove this and uncoment the commented return statement
//        return true;
        return !dbDownloadInfoVO.getLastModifiedTs().equalsIgnoreCase(serverDownloadInfoVO.getLastModifiedTs());
    }

    public static String getCredentialAuth() {
        String credentials = "merkur:sun";
        return "Basic " + Base64.encodeToString(credentials.getBytes(), Base64.NO_WRAP);
    }

    public static boolean isDownloadServiceRunning(Context ctx) {
        final ActivityManager activityManager = (ActivityManager) ctx.getSystemService(Context.ACTIVITY_SERVICE);
        final List<ActivityManager.RunningServiceInfo> services = activityManager.getRunningServices(Integer.MAX_VALUE);
        for (ActivityManager.RunningServiceInfo runningServiceInfo : services) {
            if (runningServiceInfo.service.getClassName().equals(DownloadService.class.getCanonicalName())) {
                return true;
            }
        }
        return false;
    }

    public static void stopDownloadService(Context ctx) {

    }

    public static void clearFiles(File dir) {
        File f[] = dir.listFiles();
        if (f.length > 0) {
            for (int i = 0; i < f.length; i++) {
                if (f[i].isDirectory()) {
                    clearFiles(f[i]);
                }
                if(!f[i].getName().equalsIgnoreCase("config")) {
                    f[i].delete();
                }
            }
        }
    }

    public static boolean unzipConfigFile(Context ctx) {
        String path = String.valueOf(ctx.getFilesDir());
        String zipname = "config";
        InputStream is;
        ZipInputStream zis;
        try {
            String filename;
            is = new FileInputStream(path + File.separator + zipname);
            zis = new ZipInputStream(new BufferedInputStream(is));
            ZipEntry ze;
            byte[] buffer = new byte[1024];
            int count;

            while ((ze = zis.getNextEntry()) != null) {
                filename = ze.getName();

                // Need to create directories if not exists, or
                // it will generate an Exception...
                if (ze.isDirectory()) {
                    File fmd = new File(path + File.separator + filename);
                    fmd.mkdirs();
                    continue;
                }

                FileOutputStream fout = new FileOutputStream(path + File.separator + filename);

                // cteni zipu a zapis
                while ((count = zis.read(buffer)) != -1) {
                    fout.write(buffer, 0, count);
                }

                fout.close();
                zis.closeEntry();
            }

            zis.close();
            //Delete zip FILE
            new File(path + File.separator + zipname).delete();

            //INSERT CONFIG INFO IN DB
            updateDownloadStatus(MGConstants.DownloadStatus.DOWNLOADED);
        } catch (IOException e) {
            if (e instanceof FileNotFoundException) {
                return false;
            }
            updateDownloadStatus(MGConstants.DownloadStatus.FAILED);
            e.printStackTrace();
            return false;
        }

        return true;
    }

    private static void updateDownloadStatus(int downloadStatus) {
        DownloadInfoVO downloadInfoVO = AppController.getInstance().getDatabase().getDownloadDao().getDownloadingVO(MGConstants.DownloadStatus.DOWNLOADING);
        downloadInfoVO.setStatus(downloadStatus);
        deleteOldDownloadedVO(AppController.getInstance().getDatabase());
        downloadInfoVO.setAnUpdate(false);
        AppController.getInstance().getDatabase().getDownloadDao().update(downloadInfoVO);
    }

    private static void deleteOldDownloadedVO(MGAppDatabse db) {
        DownloadInfoVO downloadInfoVO = db.getDownloadDao().getDownloadingVO(MGConstants.DownloadStatus.DOWNLOADED);
        if (downloadInfoVO != null) {
            db.getDownloadDao().deleteDownloadInfo(downloadInfoVO);
        }
    }

    public static void parseConfig(Context ctx) throws IOException, XmlPullParserException {
        parseCatalogXml(ctx);
        parseFloorXml(ctx);
    }

    private static void parseCatalogXml(Context ctx) throws IOException, XmlPullParserException {

        XmlPullParser xpp = Xml.newPullParser();
        xpp.setFeature(XmlPullParser.FEATURE_PROCESS_NAMESPACES, false);
        File catalogFile = new File(ctx.getFilesDir() + File.separator + "merkurgaming" + File.separator + "catalog" + File.separator + "catalog.xml");
        FileInputStream fis = new FileInputStream(catalogFile);
        xpp.setInput(fis, "utf-8");

        CatalogVO catalogVO = null;
        String namespace = null;
        int eventType = xpp.getEventType();
        while (eventType != XmlPullParser.END_DOCUMENT) {
            if (eventType == XmlPullParser.START_DOCUMENT) {
                System.out.println("Start document");
            } else if (eventType == XmlPullParser.START_TAG) {
                Log.d("xml", "TAG :" + xpp.getName());

                //CATALOG
                if (xpp.getName() != null && xpp.getName().equalsIgnoreCase("catalog")) {
                    catalogVO = new CatalogVO();
                    catalogVO.setTitle(xpp.getAttributeValue(namespace, "title"));
                }
                //CABINET
                if (xpp.getName() != null && xpp.getName().equalsIgnoreCase("cabinet")) {
                    CabinetVO cabinetVO = new CabinetVO();
                    cabinetVO.setType(MGConstants.CatalogItemType.CABINET);
                    cabinetVO.setId(xpp.getAttributeValue(namespace, "ID"));
                    cabinetVO.setTagLine(xpp.getAttributeValue(namespace, "tagline"));
                    cabinetVO.setBlurb(xpp.getAttributeValue(namespace, "blurb"));
                    cabinetVO.setName(xpp.getAttributeValue(namespace, "name"));
                    cabinetVO.setResPath("catalog" + File.separator + "cabinets");
                    catalogVO.getCabinetList().add(cabinetVO);
                }

                //CATEGORY
                if (xpp.getName() != null && xpp.getName().equalsIgnoreCase("category")) {
                    CategoryVO categoryVO = new CategoryVO();
                    categoryVO.setName(xpp.getAttributeValue(namespace, "name"));
                    catalogVO.getCategoryList().add(categoryVO);

                }
                //TAG
                if (xpp.getName() != null && xpp.getName().equalsIgnoreCase("tag")) {
                    TagVO tagVO = new TagVO();
                    tagVO.setId(xpp.getAttributeValue(namespace, "ID"));
                    tagVO.setEmoji(xpp.getAttributeValue(namespace, "emoji"));
                    tagVO.setName(xpp.getAttributeValue(namespace, "name"));
                    tagVO.setColor(xpp.getAttributeValue(namespace, "color"));
                    tagVO.setTintColor(xpp.getAttributeValue(namespace, "tintcolor"));
                    tagVO.setSmaller(xpp.getAttributeValue(namespace, "smaller"));
                    catalogVO.addTagToCategory(tagVO);
                }

                //TEAM
                if (xpp.getName() != null && xpp.getName().equalsIgnoreCase("team")) {
                    TeamVO teamVO = new TeamVO();
                    teamVO.setId(xpp.getAttributeValue(namespace, "ID"));
                    teamVO.setName(xpp.getAttributeValue(namespace, "name"));
                    catalogVO.getTeamList().add(teamVO);
                }

                //GAME
                if (xpp.getName() != null && xpp.getName().equalsIgnoreCase("game")) {
                    GameVO gameVO = new GameVO();
                    gameVO.setType(MGConstants.CatalogItemType.GAME);
                    gameVO.setId(xpp.getAttributeValue(namespace, "ID"));
                    gameVO.setTeam(xpp.getAttributeValue(namespace, "team"));
                    gameVO.setEmoji(xpp.getAttributeValue(namespace, "emoji"));
                    gameVO.setSw(xpp.getAttributeValue(namespace, "sw"));
                    gameVO.setName(xpp.getAttributeValue(namespace, "name"));
                    gameVO.setTagLine(xpp.getAttributeValue(namespace, "tagline"));
                    gameVO.setTheme(xpp.getAttributeValue(namespace, "theme"));
                    gameVO.setReels(xpp.getAttributeValue(namespace, "reels"));
                    gameVO.setLines(xpp.getAttributeValue(namespace, "lines"));
                    gameVO.setVolatility(xpp.getAttributeValue(namespace, "volatility"));
                    gameVO.setHitRate(xpp.getAttributeValue(namespace, "hitrate"));
                    gameVO.setRtp(xpp.getAttributeValue(namespace, "rtp"));
                    gameVO.setBannerPath("catalog" + File.separator + gameVO.getSw() + File.separator + "banners");
                    gameVO.setGalleryPath("catalog" + File.separator + gameVO.getSw() + File.separator + "gallery");
                    catalogVO.getGameList().add(gameVO);
                }

                //TEAM
                if (xpp.getName() != null && xpp.getName().equalsIgnoreCase("suite")) {
                    SuiteVO suiteVO = new SuiteVO();
                    suiteVO.setId(xpp.getAttributeValue(namespace, "ID"));
                    suiteVO.setName(xpp.getAttributeValue(namespace, "name"));
                    suiteVO.setGames(xpp.getAttributeValue(namespace, "games"));
                    catalogVO.getSuiteList().add(suiteVO);
                }


            } else if (eventType == XmlPullParser.END_TAG) {
                if (xpp.getName() != null && xpp.getName().equalsIgnoreCase("catalog")) {
                    AppController.getInstance().setCatalogVO(catalogVO);
                }
            } else if (eventType == XmlPullParser.TEXT) {
                System.out.println("Text " + xpp.getText());
            }
            eventType = xpp.next();
        }
        System.out.println("End document");

    }

    private static void parseFloorXml(Context ctx) throws IOException, XmlPullParserException {

        XmlPullParser xpp = Xml.newPullParser();
        File catalogFile = new File(ctx.getFilesDir() + File.separator + "merkurgaming" + File.separator + "floorplan" + File.separator + "floorplan.xml");
        FileInputStream fis = new FileInputStream(catalogFile);
        xpp.setInput(fis, "utf-8");

        FloorVO floorVO = null;
        String namespace = null;
        int eventType = xpp.getEventType();
        while (eventType != XmlPullParser.END_DOCUMENT) {
            if (eventType == XmlPullParser.START_DOCUMENT) {
                System.out.println("Start document");
            } else if (eventType == XmlPullParser.START_TAG) {
                Log.d("xml", "TAG :" + xpp.getName());

                //FLOOR
                if (xpp.getName() != null && xpp.getName().equalsIgnoreCase("floor")) {
                    floorVO = new FloorVO();
                    floorVO.setTitle(xpp.getAttributeValue(namespace, "title"));
                }
                //OBJECT
                if (xpp.getName() != null && xpp.getName().equalsIgnoreCase("object")) {
                    FloorObj floorObj = new FloorObj();
                    floorObj.setName(xpp.getAttributeValue(namespace, "name"));
                    floorObj.setColor(xpp.getAttributeValue(namespace, "color"));
                    floorVO.getFloorList().add(floorObj);
                }

                //LOCATION
                if (xpp.getName() != null && xpp.getName().equalsIgnoreCase("location")) {
                    FloorLocationVO floorLocationVO = new FloorLocationVO();
                    floorLocationVO.setLocationX(xpp.getAttributeValue(namespace, "x"));
                    floorLocationVO.setLocationY(xpp.getAttributeValue(namespace, "y"));
                    floorLocationVO.setLocationWidth(xpp.getAttributeValue(namespace, "width"));
                    floorLocationVO.setLocationHeight(xpp.getAttributeValue(namespace, "height"));
                    floorVO.addLocationToFloorObj(floorLocationVO);
                }

            } else if (eventType == XmlPullParser.END_TAG) {
                if (xpp.getName() != null && xpp.getName().equalsIgnoreCase("floor")) {
                    AppController.getInstance().setFloorVO(floorVO);
                }
            } else if (eventType == XmlPullParser.TEXT) {
                System.out.println("Text " + xpp.getText());
            }
            eventType = xpp.next();
        }
        System.out.println("End document");

    }

    public static Intent getDownloadIntentWithBundle(Context context) {
        Intent intent = getDownloadIntent(context);
        Bundle bundle = new Bundle();
        bundle.putString("zipUrl", NetworkConst.DOWNLOAD_URL);
        intent.putExtras(bundle);
        return intent;
    }

    public static Intent getDownloadIntent(Context context) {
        return new Intent(context, DownloadService.class);
    }

    private static String getBasepath(Context ctx) {
        return ctx.getFilesDir() + File.separator + "merkurgaming" + File.separator;
    }

    public static void loadImage(final Context ctx, final ImageView iv, String path) {
        final File file = new File(getBasepath(ctx) + path);
        if (file.exists()) {
            iv.post(new Runnable() {
                @Override
                public void run() {
                    try {
                        Glide.with(ctx)
                                .load(file)
                                .crossFade()
                                .fitCenter()
                                .into(iv);
                    } catch (IllegalArgumentException iae) {

                    }
                }
            });
        }
    }

    public static void loadImage(final Context ctx, final ImageView iv, File imgFile) {
        final File file = new File(imgFile.getPath());
        if (file.exists()) {
            iv.post(new Runnable() {
                @Override
                public void run() {
                    Glide.with(ctx)
                            .load(file)
                            .crossFade()
                            .fitCenter()
                            .into(iv);
                }
            });
        }
    }

    public static void setOrientation(Activity activity) {
        DisplayMetrics metrics = new DisplayMetrics();
        activity.getWindowManager().getDefaultDisplay().getMetrics(metrics);

        float yInches = metrics.heightPixels / metrics.ydpi;
        float xInches = metrics.widthPixels / metrics.xdpi;
        double diagonalInches = Math.sqrt(xInches * xInches + yInches * yInches);
        if (diagonalInches < 6.5) {
            int currentOrientation = activity.getResources().getConfiguration().orientation;
            if (currentOrientation == Configuration.ORIENTATION_LANDSCAPE) {
                activity.setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_SENSOR_PORTRAIT);
            }
        }
    }

    public static int[] getLocation(View view) {
        int[] location = new int[2];
        view.getLocationOnScreen(location);
        return location;
    }

    public static ArrayList<File> getGalleryFiles(Context ctx, String galleryPath, String galleryName) {
        ArrayList<File> list = new ArrayList<>();
        String path = getBasepath(ctx) + galleryPath;
        File file = new File(path);
        if (file.exists()) {
            File[] fileList = file.listFiles();
            for (int i = 0; i < fileList.length; i++) {
                if (fileList[i].getName().startsWith(galleryName)) {
                    list.add(fileList[i]);
                }
            }
        }
        return list;
    }

    public static SuiteVO getSuiteById(ArrayList<SuiteVO> suiteList, String suiteId) {
        for (SuiteVO suiteVO : suiteList) {
            if (suiteId.equalsIgnoreCase(suiteVO.getName())) {
                return suiteVO;
            }
        }
        return null;
    }

    public static String getFileSizeInMB(long fileSizeInBytes) {
        long fileSizeInKB = fileSizeInBytes / 1024;
        return String.valueOf(fileSizeInKB / 1024);
    }

    public static void clearInvalidDownloadVO(MGAppDatabse db) {
        List<DownloadInfoVO> downloadInfoVOList = db.getDownloadDao().getAllDownloadedVO();
        for (DownloadInfoVO dVO : downloadInfoVOList) {
            if (dVO.getStatus() == MGConstants.DownloadStatus.DOWNLOADING) {
                db.getDownloadDao().deleteDownloadInfo(dVO);
            }
        }
    }


}
