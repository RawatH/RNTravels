package app.mg.merkur.com.mgapp.models.catalog;

import java.io.Serializable;

/**
 * Created by hrawat on 12-03-2018.
 */

public class CatalogItemVO implements Serializable {

    public int type;

    public int getType() {
        return type;
    }

    public void setType(int type) {
        this.type = type;
    }

}
