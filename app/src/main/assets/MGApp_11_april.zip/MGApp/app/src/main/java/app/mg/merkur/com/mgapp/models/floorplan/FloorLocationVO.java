package app.mg.merkur.com.mgapp.models.floorplan;

/**
 * Created by hrawat on 30-01-2018.
 */

public class FloorLocationVO {

    private String locationX;
    private String locationY;
    private String locationWidth;
    private String locationHeight;

    public String getLocationX() {
        return locationX;
    }

    public void setLocationX(String locationX) {
        this.locationX = locationX;
    }

    public String getLocationY() {
        return locationY;
    }

    public void setLocationY(String locationY) {
        this.locationY = locationY;
    }

    public String getLocationWidth() {
        return locationWidth;
    }

    public void setLocationWidth(String locationWidth) {
        this.locationWidth = locationWidth;
    }

    public String getLocationHeight() {
        return locationHeight;
    }

    public void setLocationHeight(String locationHeight) {
        this.locationHeight = locationHeight;
    }
}
