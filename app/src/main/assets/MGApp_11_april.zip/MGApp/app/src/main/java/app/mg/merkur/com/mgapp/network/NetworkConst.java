package app.mg.merkur.com.mgapp.network;

/**
 * Created by hrawat on 25-01-2018.
 */

public class NetworkConst {
    public static final String DOWNLOAD_URL = "http://expo.cityvisio.com/merkurgaming.zip";
    public static final String PRODUCT_URL = "http://video.cityvisio.com";
}
