package app.mg.merkur.com.mgapp.app;

import android.app.Application;

import app.mg.merkur.com.mgapp.db.database.MGAppDatabse;
import app.mg.merkur.com.mgapp.manager.AppController;

/**
 * Created by hrawat on 18-01-2018.
 */

public class MGApp extends Application {

    private MGAppDatabse db;
    private AppController appController;
    @Override
    public void onCreate() {
        super.onCreate();
        db = MGAppDatabse.getAppDatabase(this);
        appController = AppController.getInstance();
        appController.setDatabase(db);
    }

}
