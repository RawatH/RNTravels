package app.mg.merkur.com.mgapp.models.catalog;

import android.os.Parcel;
import android.os.Parcelable;
import android.support.annotation.NonNull;

import java.io.File;
import java.io.Serializable;

import app.mg.merkur.com.mgapp.manager.AppController;
import app.mg.merkur.com.mgapp.util.MGConstants;

/**
 * Created by hrawat on 18-01-2018.
 */

public class GameVO extends CatalogItemVO implements Parcelable {
    private String id;
    private String team;
    private String emoji;
    private String sw;
    private String name;
    private String tagLine;
    private String theme;
    private String reels;
    private String lines;
    private String volatility;
    private String hitRate;
    private String rtp;
    private String bannerPath;
    private String galleryPath;

    public GameVO(){

    }
    // get and set method

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeString(id);
        dest.writeString(team);
        dest.writeString(emoji);
        dest.writeString(sw);
        dest.writeString(name);
        dest.writeString(tagLine);
        dest.writeString(theme);
        dest.writeString(reels);
        dest.writeString(lines);
        dest.writeString(volatility);
        dest.writeString(hitRate);
        dest.writeString(rtp);
        dest.writeString(bannerPath);
        dest.writeString(galleryPath);
    }

    // Creator
    public static final Parcelable.Creator CREATOR
            = new Parcelable.Creator() {
        public GameVO createFromParcel(Parcel in) {
            return new GameVO(in);
        }

        public GameVO[] newArray(int size) {
            return new GameVO[size];
        }
    };

    // "De-parcel object
    public GameVO(Parcel in) {
        id = in.readString();
        team = in.readString();
        emoji = in.readString();
        sw = in.readString();
        name = in.readString();
        tagLine = in.readString();
        team = in.readString();
        theme = in.readString();
        reels = in.readString();
        lines = in.readString();
        volatility = in.readString();
        hitRate = in.readString();
        rtp = in.readString();
        bannerPath = in.readString();
        galleryPath = in.readString();
    }


    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getTeam() {
        return team;
    }

    public void setTeam(String team) {
        this.team = team;
    }

    public String getEmoji() {
        return emoji;
    }

    public void setEmoji(String emoji) {
        this.emoji = emoji;
    }

    public String getSw() {
        return sw;
    }

    public void setSw(String sw) {
        this.sw = sw;
    }

    public String getName() {
        return name.trim();
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getTagLine() {
        return tagLine;
    }

    public void setTagLine(String tagLine) {
        this.tagLine = tagLine;
    }

    public String getTheme() {
        return theme;
    }

    public void setTheme(String theme) {
        this.theme = theme;
    }

    public String getReels() {
        return reels;
    }

    public void setReels(String reels) {
        this.reels = reels;
    }

    public String getLines() {
        return lines;
    }

    public void setLines(String lines) {
        this.lines = lines;
    }

    public String getVolatility() {
        return volatility;
    }

    public void setVolatility(String volatility) {
        this.volatility = volatility;
    }

    public String getHitRate() {
        return hitRate;
    }

    public void setHitRate(String hitRate) {
        this.hitRate = hitRate;
    }

    public String getRtp() {
        return rtp;
    }

    public void setRtp(String rtp) {
        this.rtp = rtp;
    }

    public String getBannerPath() {
        return bannerPath;
    }

    public void setBannerPath(String bannerPath) {
        this.bannerPath = bannerPath;
    }

    public String getResCompletePath() {
        return bannerPath + File.separator + getId() + ".jpg";
    }

    public String getGalleryPath() {
        return galleryPath;
    }

    public void setGalleryPath(String galleryPath) {
        this.galleryPath = galleryPath;
    }

    public String fetchVolatility() {
        TagVO tagVO = AppController.getInstance().getTagForCategory(MGConstants.Category.VOLATILITY, "VOL" + getVolatility());
        if (tagVO != null) {
            return tagVO.getName();
        }
        return null;
    }

    @Override
    protected Object clone() throws CloneNotSupportedException {
        return super.clone();
    }

    @Override
    public boolean equals(Object obj) {
        GameVO gVO = (GameVO) obj;
        if (this.getName().equalsIgnoreCase(gVO.getName())) {
            return true;
        } else {
            return false;
        }
    }

}
