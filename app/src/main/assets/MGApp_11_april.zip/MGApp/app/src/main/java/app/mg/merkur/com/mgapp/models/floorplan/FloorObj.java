package app.mg.merkur.com.mgapp.models.floorplan;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by hrawat on 30-01-2018.
 */

public class FloorObj {

    private String name;
    private String color;
    private List<FloorLocationVO> floorLocationList = new ArrayList<>();

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getColor() {
        return color;
    }

    public void setColor(String color) {
        this.color = color;
    }

    public List<FloorLocationVO> getFloorLocationList() {
        return floorLocationList;
    }

    public void setFloorLocationList(List<FloorLocationVO> floorLocationList) {
        this.floorLocationList = floorLocationList;
    }
}
