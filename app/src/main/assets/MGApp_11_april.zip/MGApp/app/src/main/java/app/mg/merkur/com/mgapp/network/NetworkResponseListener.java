package app.mg.merkur.com.mgapp.network;

import com.android.volley.NetworkResponse;
import com.android.volley.VolleyError;

/**
 * Created by hrawat on 06-04-2018.
 */

public interface NetworkResponseListener<T> {
    void onSuccessResponse(T data , int requestTag);
    void onErrorResponse(VolleyError error , int requestTag);
    void parseNetworkResponse(NetworkResponse response);
}
