package app.mg.merkur.com.mgapp.db.database;

import android.arch.persistence.room.Database;
import android.arch.persistence.room.Room;
import android.arch.persistence.room.RoomDatabase;
import android.content.Context;

import app.mg.merkur.com.mgapp.db.dao.DownloadDao;
import app.mg.merkur.com.mgapp.models.download.DownloadInfoVO;

/**
 * Created by hrawat on 29-01-2018.
 */

@Database(entities = {DownloadInfoVO.class},version = 1)
public abstract class MGAppDatabse extends RoomDatabase {

    private static MGAppDatabse DATABSE_INSTANCE;
    private static String DB_NAME = "MG_APP_DB";
    public abstract DownloadDao getDownloadDao();

    public static MGAppDatabse getAppDatabase(Context context) {
        if (DATABSE_INSTANCE == null) {
            DATABSE_INSTANCE = Room.databaseBuilder(context.getApplicationContext(), MGAppDatabse.class, MGAppDatabse.DB_NAME)
                    .allowMainThreadQueries()
                    .build();
        }

        return DATABSE_INSTANCE;
    }

    public static void destoryInstance(){
        DATABSE_INSTANCE = null;
    }
}
