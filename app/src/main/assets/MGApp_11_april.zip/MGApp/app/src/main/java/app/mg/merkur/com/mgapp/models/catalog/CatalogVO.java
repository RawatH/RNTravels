package app.mg.merkur.com.mgapp.models.catalog;

import android.util.Log;
import java.text.Collator;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.LinkedHashMap;
import java.util.Locale;
import app.mg.merkur.com.mgapp.util.MGConstants;
import app.mg.merkur.com.mgapp.util.Util;

/**
 * Created by hrawat on 18-01-2018.
 */

public class CatalogVO {
    private String title;
    private ArrayList<CabinetVO> cabinetList = new ArrayList<>();
    private ArrayList<GameVO> gameList = new ArrayList<>();
    private ArrayList<TeamVO> teamList = new ArrayList<>();
    private ArrayList<SuiteVO> suiteList = new ArrayList<>();
    private ArrayList<CategoryVO> categoryList = new ArrayList<>();

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public ArrayList getCabinetList() {
        return cabinetList;
    }

    public void setCabinetList(ArrayList<CabinetVO> cabinetList) {
        this.cabinetList = cabinetList;
    }

    public ArrayList getGameList() {
        Collections.sort(gameList, localeComparator);
        return gameList;
    }

    //Comparators
    private Comparator<GameVO> localeComparator = new Comparator<GameVO>() {
        @Override
        public int compare(GameVO objA, GameVO objB) {
            Collator collator = Collator.getInstance(Locale.GERMANY);
            return collator.compare(objA.getName().trim(),objB.getName().trim());
        }
    };


    public void setGameList(ArrayList<GameVO> gameList) {
        this.gameList = gameList;
    }

    public ArrayList<TeamVO> getTeamList() {
        return teamList;
    }

    public void setTeamList(ArrayList<TeamVO> teamList) {
        this.teamList = teamList;
    }

    public ArrayList<CategoryVO> getCategoryList() {
        return categoryList;
    }

    public void setCategoryList(ArrayList<CategoryVO> categoryList) {
        this.categoryList = categoryList;
    }

    public ArrayList<SuiteVO> getSuiteList() {
        return suiteList;
    }

    public void setSuiteList(ArrayList<SuiteVO> suiteList) {
        this.suiteList = suiteList;
    }

    public void addTagToCategory(TagVO tagVO) {
        CategoryVO categoryVO = getCategoryList().get(getCategoryList().size() - 1);
        tagVO.setCategoryName(categoryVO.getName());
        categoryVO.getTagList().add(tagVO);
    }

    public TagVO getTagFromCategory(String categoryName, String tagId) {
        for (CategoryVO categoryVO : getCategoryList()) {
            if (categoryVO.getName().equalsIgnoreCase(categoryName)) {
                return categoryVO.getTagById(tagId);
            }
        }
        return null;
    }

    public LinkedHashMap<String, ArrayList> getFilterList() {
        LinkedHashMap<String, ArrayList> filterMap = new LinkedHashMap<>();
        filterMap.put(MGConstants.Filter.SUITES, getSuiteList());
        for (CategoryVO categoryVO : categoryList) {
            filterMap.put(categoryVO.getName(), categoryVO.getTagList());
        }
        return filterMap;
    }

    public String getVolatilityByName(String name) {
        for (CategoryVO cVO : getCategoryList()) {
            if (cVO.getName().equalsIgnoreCase(MGConstants.Filter.VOLATILITY)) {
                for (TagVO tVO : cVO.getTagList()) {
                    if (tVO.getId().equalsIgnoreCase(name)) {
                        return tVO.getName();
                    }
                }
            }
        }
        return null;
    }


    public String getTeamNameById(String teamId) {
        for (TeamVO tVO : getTeamList()) {
            if (tVO.getId().equalsIgnoreCase(teamId)) {
                return tVO.getName();
            }
        }
        return null;
    }

    public String getEmojiForName(String name) {

        for (CategoryVO categoryVO : getCategoryList()) {
            String emoji = categoryVO.getEmojiForName(name);
            if (emoji != null) {
                return emoji;
            }
        }
        return null;
    }

    public ArrayList<GameVO> getSuiteGames(String suiteId) {
        SuiteVO suiteVO = Util.getSuiteById(getSuiteList(), suiteId);
        ArrayList<String> suiteGameIdsList = suiteVO.getGameIdList();
        ArrayList<GameVO> filteredList = new ArrayList<>();
        for (Object obj : getGameList()) {
            GameVO gameVO = (GameVO)obj;
            Log.d("filter", "---" + gameVO.getId());
            if (suiteGameIdsList.contains(gameVO.getId().trim())) {
                Log.d("filter", "----------------" + gameVO.getId());
                filteredList.add(gameVO);
                suiteGameIdsList.remove(gameVO.getId());
                if (suiteGameIdsList.size() == 0) {
                    return filteredList;
                }
            }
        }
        return filteredList;
    }
}
