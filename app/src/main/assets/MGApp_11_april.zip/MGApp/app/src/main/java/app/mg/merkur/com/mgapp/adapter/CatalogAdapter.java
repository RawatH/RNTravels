package app.mg.merkur.com.mgapp.adapter;

import android.content.Context;
import android.graphics.Typeface;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseExpandableListAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.HashMap;

import app.mg.merkur.com.mgapp.R;
import app.mg.merkur.com.mgapp.app.MGApp;
import app.mg.merkur.com.mgapp.manager.AppController;
import app.mg.merkur.com.mgapp.models.catalog.CabinetVO;
import app.mg.merkur.com.mgapp.models.catalog.CatalogVO;
import app.mg.merkur.com.mgapp.models.catalog.GameVO;
import app.mg.merkur.com.mgapp.util.Util;

/**
 * Created by hrawat on 30-01-2018.
 */

public class CatalogAdapter extends BaseExpandableListAdapter {
    private Context ctx;
    private ArrayList<String> headerList;
    private HashMap<String, ArrayList> childDataMap;
    private CatalogVO catalogVO;

    public CatalogAdapter(Context ctx) {
        this.ctx = ctx;
        this.catalogVO = AppController.getInstance().getCatalogVO();
        prepareDataSet();
    }

    private void prepareDataSet() {
        headerList = new ArrayList<>();
        headerList.add("Cabinets");
        headerList.add("Games");
        childDataMap = new HashMap<>();
        childDataMap.put(headerList.get(0), catalogVO.getCabinetList());
        childDataMap.put(headerList.get(1), catalogVO.getGameList());
    }


    @Override
    public int getGroupCount() {
        return headerList.size();
    }

    @Override
    public int getChildrenCount(int groupPosition) {
        return childDataMap.get(headerList.get(groupPosition)).size();
    }

    @Override
    public Object getGroup(int groupPosition) {
        return headerList.get(groupPosition);
    }

    @Override
    public Object getChild(int groupPosition, int childPosition) {
        return childDataMap.get(headerList.get(groupPosition)).get(childPosition);
    }

    @Override
    public long getGroupId(int groupPosition) {
        return groupPosition;
    }

    @Override
    public long getChildId(int groupPosition, int childPosition) {
        return childPosition;
    }

    @Override
    public boolean hasStableIds() {
        return false;
    }

    @Override
    public View getGroupView(int groupPosition, boolean isExpanded, View convertView, ViewGroup parent) {
        String headerTitle = (String) getGroup(groupPosition);
        if (convertView == null) {
            LayoutInflater inflater = (LayoutInflater) ctx.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
            convertView = inflater.inflate(R.layout.list_header, null);
        }

        TextView lblListHeader = (TextView) convertView.findViewById(R.id.listTitle);
        lblListHeader.setTypeface(null, Typeface.BOLD);
        lblListHeader.setText(headerTitle);

        return convertView;
    }

    @Override
    public View getChildView(int groupPosition, int childPosition, boolean isLastChild, View convertView, ViewGroup parent) {

        View rowView = convertView;
        if (rowView == null) {
            LayoutInflater layoutInflater = (LayoutInflater) ctx.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
            switch (getChildType(groupPosition, childPosition)) {
                case 0:
                    rowView = layoutInflater.inflate(R.layout.cabinet_row_item, null);
                    CabinetViewHolder cabinetViewHolder = new CabinetViewHolder();
                    cabinetViewHolder.cabinetName = rowView.findViewById(R.id.cabinetName);
                    cabinetViewHolder.cabinetIcon =  rowView.findViewById(R.id.cabinetIcon);
                    cabinetViewHolder.cabinetTagline = rowView.findViewById(R.id.cabinetTagline);
                    rowView.setTag(cabinetViewHolder);
                    break;

                case 1:
                    rowView = layoutInflater.inflate(R.layout.game_row_item, null);
                    GameViewHolder gameViewHolder = new GameViewHolder();
                    gameViewHolder.gameName = rowView.findViewById(R.id.gameName);
                    gameViewHolder.gameTagline = rowView.findViewById(R.id.gameTagline);
                    rowView.setTag(gameViewHolder);
                    break;
            }

        }

        switch (getChildType(groupPosition, childPosition)) {
            case 0:
                CabinetVO cabinetVO = (CabinetVO) getChild(groupPosition, childPosition);
                CabinetViewHolder cabinetViewHolder = (CabinetViewHolder) rowView.getTag();
                cabinetViewHolder.cabinetName.setText(cabinetVO.getName());
                cabinetViewHolder.cabinetTagline.setText(cabinetVO.getTagLine());
                Util.loadImage(ctx,cabinetViewHolder.cabinetIcon,"catalog/cabinets/"+cabinetVO.getId());

                break;
            case 1:
                GameVO gameVO = (GameVO) getChild(groupPosition, childPosition);
                GameViewHolder gameViewHolder = (GameViewHolder) rowView.getTag();
                gameViewHolder.gameName.setText(gameVO.getName());
                gameViewHolder.gameTagline.setText(gameVO.getTagLine());

                break;
            default:
                break;
        }


        return rowView;
    }

    @Override
    public boolean isChildSelectable(int groupPosition, int childPosition) {
        return true;
    }

    @Override
    public int getChildTypeCount() {
        return headerList.size();
    }

    @Override
    public int getChildType(int groupPosition, int childPosition) {
        return groupPosition;
    }

    static class CabinetViewHolder {
        public TextView cabinetName;
        public ImageView cabinetIcon;
        public TextView cabinetTagline;
    }

    static class GameViewHolder {
        public TextView gameName;
        public TextView gameTagline;
    }


}
