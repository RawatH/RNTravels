package app.mg.merkur.com.mgapp.component.ui.fragment.catalog;

import android.animation.Animator;
import android.animation.ObjectAnimator;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.res.Resources;
import android.graphics.Color;
import android.graphics.drawable.BitmapDrawable;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.support.annotation.Nullable;
import android.support.design.widget.FloatingActionButton;
import android.support.v4.content.ContextCompat;
import android.support.v4.content.LocalBroadcastManager;
import android.support.v4.view.PagerTabStrip;
import android.support.v4.view.ViewPager;
import android.support.v7.widget.GridLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import android.widget.PopupWindow;
import android.widget.TextView;

import com.android.volley.NetworkResponse;
import com.android.volley.Request;

import org.xmlpull.v1.XmlPullParserException;

import java.io.IOException;

import app.mg.merkur.com.mgapp.R;
import app.mg.merkur.com.mgapp.adapter.CatalogListAdapter;
import app.mg.merkur.com.mgapp.adapter.CatalogPagerAdapter;
import app.mg.merkur.com.mgapp.adapter.FilterAdapter;
import app.mg.merkur.com.mgapp.component.ui.custom.BannerView;
import app.mg.merkur.com.mgapp.component.ui.fragment.BaseFragment;
import app.mg.merkur.com.mgapp.manager.AppController;
import app.mg.merkur.com.mgapp.manager.FilterManager;
import app.mg.merkur.com.mgapp.models.catalog.CatalogVO;
import app.mg.merkur.com.mgapp.models.download.DownloadInfoVO;
import app.mg.merkur.com.mgapp.network.NetworkConst;
import app.mg.merkur.com.mgapp.network.NetworkRequestor;
import app.mg.merkur.com.mgapp.util.AnimationListener;
import app.mg.merkur.com.mgapp.util.MGConstants;
import app.mg.merkur.com.mgapp.util.Util;

/**
 * Created by hrawat on 17-01-2018.
 */

public class CatalogFragment extends BaseFragment implements ViewPager.OnPageChangeListener, View.OnClickListener, CatalogPagerAdapter.AdapterCommunicator, FilterAdapter.FilterSelectionListener {

    private ViewPager pager;
    private CatalogPagerAdapter pagerAdapter;
    private PagerTabStrip tabStrip;
    private FloatingActionButton gameSearchAction;
    private BannerView bannerView;
    private PopupWindow filterPopup;
    private CatalogVO catalogVO;
    private int selectedCatalogItem;
    private View rootView;
    private MenuItem filterMenuItem;
    private View filterLayout;
    private DownloadInfoVO downloadInfoVO;

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {

        View view = inflater.inflate(R.layout.fragment_catalog, container, false);
        initView(view);
        setHasOptionsMenu(true);
        selectedCatalogItem = CatalogListAdapter.CatalogType.CABINET;

        return view;

    }

    private void initView(View view) {
        gameSearchAction = view.findViewById(R.id.gameSearch);
        gameSearchAction.setOnClickListener(this);

        bannerView = view.findViewById(R.id.updateBanner);
        pager = view.findViewById(R.id.catalogPager);

        tabStrip = view.findViewById(R.id.title_strip);
        tabStrip.setDrawFullUnderline(false);
        tabStrip.setTabIndicatorColor(ContextCompat.getColor(getActivity(), R.color.white));
        initCatalog();
    }

    private void initCatalog() {

        //If DOWNLOADED data is available just render the view
        if (AppController.getInstance().isAppInitialized()) {
            parseAndRenderUI();
        }

        if (Util.isDownloadServiceRunning(getContext())) {
            downloadInfoVO = appController.getDatabase().getDownloadDao().getDownloadingVO(MGConstants.DownloadStatus.DOWNLOADING);
            bannerView.setActionListener(CatalogFragment.this);
            bannerView.setVisibility(View.VISIBLE);
            bannerView.reloadDownlaodUI();
        } else {
            //If download service is not running just clear the DOWNLOADING state obj from DB
            Util.clearInvalidDownloadVO(AppController.getInstance().getDatabase());
            getZipInfo();
        }
    }

    public void getZipInfo() {
        new NetworkRequestor.RequestBuilder(getContext())
                .setRequestType(Request.Method.HEAD)
                .setRequestUrl(NetworkConst.DOWNLOAD_URL)
                .setRequestTag(MGConstants.RequestTag.DOWNLOAD_INFO)
                .setResponseListener(this)
                .build()
                .getZipInformation();
    }


    @Override
    public void onResume() {
        super.onResume();
        if(Util.isDownloadServiceRunning(context)) {
            registerDownloadReceiver();
        }
        if (catalogVO == null) {
            setTitle(getString(R.string.app_name));
        } else {
            setTitle(catalogVO.getTitle());
        }
        listener.updateToolbarTitle();
    }


    /**
     * Network callbacks
     */

    @Override
    public void parseNetworkResponse(NetworkResponse response) {
        String lastModified = response.headers.get("Last-Modified");
        final long contentLength = Long.valueOf(response.headers.get("Content-Length"));
        downloadInfoVO = new DownloadInfoVO();
        downloadInfoVO.setStatus(MGConstants.DownloadStatus.DOWNLOADING);
        downloadInfoVO.setContentLength(String.valueOf(contentLength));
        downloadInfoVO.setLastModifiedTs(lastModified);
        renderBanner();
    }

    private void renderBanner() {
        if (AppController.getInstance().isAppInitialized()) {
            downloadInfoVO.setAnUpdate(true);
            if (Util.isUpdateAvailable(appController.getDatabase(), downloadInfoVO)) {
                renderBannerView();
            }
        } else {
            downloadInfoVO.setAnUpdate(false);
            renderBannerView();
        }
    }

    private void renderBannerView() {

        new Handler(Looper.getMainLooper()).post(new Runnable() {
            @Override
            public void run() {
                String actionText = downloadInfoVO.isAnUpdate() ? getResources().getString(R.string.update) : getResources().getString(R.string.download);
                String bannerText = downloadInfoVO.isAnUpdate() ? getResources().getString(R.string.update_available) : getResources().getString(R.string.download_text);
                bannerText = String.format(bannerText, Util.getFileSizeInMB(Long.valueOf(downloadInfoVO.getContentLength())));
                bannerView.setActionListener(CatalogFragment.this);
                bannerView.setVisibility(View.VISIBLE);
                bannerView.updateText(actionText, bannerText);
            }
        });
    }

    @Override
    public void onActionClicked() {
        Util.toast(getContext(), "Downloading...");
        downloadZip();
    }

    @Override
    public void onDownloadCancelled() {
        unregisterDownloadReceiver();
        getContext().stopService(Util.getDownloadIntent(getContext()));
        Util.toast(getContext(), getResources().getString(R.string.download_cancel));
        //Clear the downloading obj  from database
        DownloadInfoVO dInfoVO = appController.getDatabase().getDownloadDao().getDownloadingVO(MGConstants.DownloadStatus.DOWNLOADING);
        appController.getDatabase().getDownloadDao().deleteDownloadInfo(dInfoVO);
        getZipInfo();
    }

    private void setupBanner() {
        ObjectAnimator oa = ObjectAnimator.ofFloat(bannerView, "alpha", 0, 1.0f);
        oa.addListener(new AnimationListener() {
            public void onAnimationStart(Animator animation) {
                bannerView.setVisibility(View.VISIBLE);
            }
        });
        oa.setDuration(500);
        oa.start();
    }

    //Pager Listener
    @Override
    public void onPageScrolled(int position, float positionOffset, int positionOffsetPixels) {

    }

    @Override
    public void onPageSelected(int position) {
        switch (position) {
            case CatalogListAdapter.CatalogType.CABINET:
                selectedCatalogItem = CatalogListAdapter.CatalogType.CABINET;
                gameSearchAction.setVisibility(View.GONE);
                toggleSearchUI(View.GONE);
                break;
            case CatalogListAdapter.CatalogType.GAME:
                selectedCatalogItem = CatalogListAdapter.CatalogType.GAME;
                toggleSearchUI(View.VISIBLE);
                gameSearchAction.setVisibility(View.VISIBLE);
                break;
        }

        listener.invalidateMenu();

    }


    @Override
    public void onCreateOptionsMenu(Menu menu, MenuInflater inflater) {
        if (selectedCatalogItem == CatalogListAdapter.CatalogType.GAME) {
            inflater.inflate(R.menu.catalog_menu, menu);
            filterMenuItem = menu.findItem(R.id.action_filter);
            updateFilterIcon();
        }
        super.onCreateOptionsMenu(menu, inflater);
    }

    private void updateFilterIcon() {
        filterMenuItem.setIcon(FilterManager.getInstance().isAnyFilterSelected() ? R.drawable.ic_filter_selected : R.drawable.filter_icon);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case R.id.action_filter:
                showFilterPopup(getActivity().findViewById(R.id.action_filter));
                return true;
            default:
                return super.onOptionsItemSelected(item);
        }
    }

    private void toggleSearchUI(int visiblity) {
        gameSearchAction.setVisibility(visiblity);
        listener.toggleFilterView(visiblity);
    }

    @Override
    public void onPageScrollStateChanged(int state) {

    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.gameSearch:
                pagerAdapter.toggleSearchView(pager.findViewWithTag("View" + pager.getCurrentItem()));
                break;
        }
    }

    @Override
    public void changeSearchImageResource(int drawable) {
        gameSearchAction.setImageResource(drawable);
    }

    @Override
    public void shiftFloatingActionTo(int position) {
        FrameLayout parent = (FrameLayout) gameSearchAction.getParent();
        int[] loc = new int[2];
        gameSearchAction.getLocationOnScreen(loc);

        ObjectAnimator oa = null;
        switch (position) {
            case 0:
                oa = ObjectAnimator.ofFloat(gameSearchAction, View.TRANSLATION_Y, 0f, -(parent.getHeight() / 2));
                break;
            case 1:
                if (loc[1] < parent.getHeight() - 100) {
                    oa = ObjectAnimator.ofFloat(gameSearchAction, View.TRANSLATION_Y, -(parent.getHeight() / 2), 0);
                }
                break;
        }

        if (oa != null) {
            oa.setDuration(500);
            oa.start();
        }
    }

    @Override
    public void loadFrag(int fragId, Bundle bundle, boolean addToBackstack, String backstackTag) {
        listener.loadFrag(fragId, bundle, addToBackstack, backstackTag);
    }

    @Override
    public void onStop() {
        super.onStop();
        unregisterDownloadReceiver();
        if (filterPopup != null && filterPopup.isShowing()) {
            filterPopup.dismiss();
        }
    }

    private void registerDownloadReceiver() {
        LocalBroadcastManager.getInstance(getContext()).registerReceiver(mMessageReceiver, new IntentFilter(MGConstants.Action.DOWNLOAD));
        LocalBroadcastManager.getInstance(getContext()).registerReceiver(mConnectivityReceiver, new IntentFilter(MGConstants.Action.DOWNLOAD));
    }

    private void unregisterDownloadReceiver() {
        LocalBroadcastManager.getInstance(getContext()).unregisterReceiver(mMessageReceiver);
    }


    public void showFilterPopup(View anchorView) {

        try {
            LayoutInflater inflater = (LayoutInflater) getActivity().getSystemService(Context.LAYOUT_INFLATER_SERVICE);
            filterLayout = inflater.inflate(R.layout.filter_layout, null);

            RecyclerView filterList = filterLayout.findViewById(R.id.filterList);
            final FilterAdapter filterAdapter = new FilterAdapter(getContext(), catalogVO.getFilterList(), this);
            filterList.setAdapter(filterAdapter);
            GridLayoutManager manager = new GridLayoutManager(getContext(), 2);
            manager.setSpanSizeLookup(new GridLayoutManager.SpanSizeLookup() {
                @Override
                public int getSpanSize(int position) {
                    switch (filterAdapter.getItemViewType(position)) {
                        case FilterAdapter.TYPE.HEADER:
                            return 2;
                        default:
                            return 1;
                    }
                }
            });

            filterList.setLayoutManager(manager);


            //FILTER ANY
            final TextView filterAny = filterLayout.findViewById(R.id.filterAny);
            //FILTER ALL
            final TextView filterAll = filterLayout.findViewById(R.id.filterAll);

            filterAny.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    filterAny.setTextColor(Color.WHITE);
                    filterAny.setBackgroundResource(R.drawable.left_rounded_rect_selected);
                    filterAll.setTextColor(getResources().getColor(R.color.blue));
                    filterAll.setBackgroundResource(R.drawable.right_rounded_rect);
                    appController.getFilterManager().setFilterQuery(MGConstants.FilterQuery.ANY);
                }
            });

            filterAll.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    if(appController.getFilterManager().isAnyFilterSelected() && appController.getFilterManager().isAllFilterValid()) {
                        filterAny.setTextColor(getResources().getColor(R.color.blue));
                        filterAny.setBackgroundResource(R.drawable.left_rounded_rect);
                        filterAll.setTextColor(Color.WHITE);
                        filterAll.setBackgroundResource(R.drawable.right_rounded_rect_selected);
                        appController.getFilterManager().setFilterQuery(MGConstants.FilterQuery.ALL);
                    }
                }
            });

            switch (AppController.getInstance().getFilterManager().getFilterQuery()) {
                case MGConstants.FilterQuery.ANY:
                    filterAny.performClick();
                    break;
                case MGConstants.FilterQuery.ALL:
                    filterAll.performClick();
                    break;
            }

            //FILTER RESET
            TextView reset = filterLayout.findViewById(R.id.filterReset);
            reset.setEnabled(FilterManager.getInstance().isAnyFilterSelected());
            if (FilterManager.getInstance().isAnyFilterSelected()) {
                reset.setTextColor(ContextCompat.getColor(context, R.color.blue));
            } else {
                reset.setTextColor(ContextCompat.getColor(context, R.color.light_grey));
            }

            reset.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    filterAny.performClick();
                    filterAdapter.resetFilter(catalogVO.getFilterList());
                    pagerAdapter.renderFilteredList(AppController.getInstance().getCatalogVO().getGameList(), pager.findViewWithTag("View1"));
                }
            });

            Resources r = getResources();
            float heightPX = r.getDimension(R.dimen.filter_popup_height);
            float widthPX = r.getDimension(R.dimen.filter_popup_width);

            filterPopup = new PopupWindow(filterLayout, (int) widthPX, (int) heightPX, true);
            filterPopup.setFocusable(true);
            filterPopup.setOutsideTouchable(true);
            filterPopup.setBackgroundDrawable(new BitmapDrawable());

            TextView done = filterLayout.findViewById(R.id.filterDone);
            done.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    filterPopup.dismiss();
                    if (FilterManager.getInstance().isAnyFilterSelected()) {
                        pagerAdapter.renderFilteredList(FilterManager.getInstance().getFilteredList(), pager.findViewWithTag("View1"));
                    }

                }
            });

            filterPopup.showAsDropDown(anchorView, (int) anchorView.getX(), (int) anchorView.getY());

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void filterGamesList() {
        pagerAdapter.filterGameList(pager.findViewWithTag("View" + pager.getCurrentItem()));
    }

    private void resetGamesList() {
        pagerAdapter.resetGameList(pager.findViewWithTag("View" + pager.getCurrentItem()));
    }

    @Override
    public void onFilterToggled() {
        TextView reset = filterLayout.findViewById(R.id.filterReset);
        reset.setEnabled(FilterManager.getInstance().isAnyFilterSelected());
        if (FilterManager.getInstance().isAnyFilterSelected()) {
            reset.setTextColor(ContextCompat.getColor(context, R.color.blue));
        } else {
            reset.setTextColor(ContextCompat.getColor(context, R.color.light_grey));
        }
        updateFilterIcon();

        if(appController.getFilterManager().getFilterQuery() == MGConstants.FilterQuery.ALL) {
            if (!appController.getFilterManager().isAnyFilterSelected() || !appController.getFilterManager().isAllFilterValid()) {
                filterLayout.findViewById(R.id.filterAny).performClick();
            }
        }
    }


    /**
     * Download and parse
     **/

    private void parseAndRenderUI() {
        try {
            Util.parseConfig(getContext());
            catalogVO = AppController.getInstance().getCatalogVO();
            new Handler(Looper.getMainLooper()).post(new Runnable() {
                @Override
                public void run() {
                    setTitle(catalogVO.getTitle());
                    pager.addOnPageChangeListener(CatalogFragment.this);
                    pagerAdapter = new CatalogPagerAdapter(getContext(), CatalogFragment.this);
                    pager.setAdapter(pagerAdapter);
                }
            });

        } catch (IOException | XmlPullParserException e) {
            //TODO :  DOWNLOADED FILE CORRUPT . CLEAN AND DOWNLAOD AGAIN
            Util.toast(context, "Corrupt file");
        }
    }

    private void downloadZip() {
        downloadInfoVO.setDownloadTs(String.valueOf(System.currentTimeMillis()));
        appController.getDatabase().getDownloadDao().insert(downloadInfoVO);
        registerDownloadReceiver();
        LocalBroadcastManager.getInstance(getContext()).registerReceiver(mConnectivityReceiver, new IntentFilter(MGConstants.Action.CONNECTIVITY));
        getContext().startService(Util.getDownloadIntentWithBundle(getContext()));
    }


    /**
     * Download receiver
     */
    private BroadcastReceiver mMessageReceiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, final Intent intent) {

            new Handler().post(new Runnable() {
                @Override
                public void run() {
                    int progress = intent.getIntExtra("progress", -1);
                    int downloadStatus = intent.getIntExtra("downloadStatus", MGConstants.DownloadStatus.FAILED);
                    switch (downloadStatus) {
                        case MGConstants.DownloadStatus.SUCCESS:
                            unregisterDownloadReceiver();
                            if (downloadInfoVO.isAnUpdate()) {
                                Util.toast(getContext(), getString(R.string.update_finished));
                                Util.clearFiles(getContext().getFilesDir());
                                //Todo : delete the old downloaded vo and update the download status for new update
                            } else {
                                Util.toast(getContext(), getString(R.string.download_success));
                            }
                            Util.unzipConfigFile(getContext());
                            parseAndRenderUI();
                            bannerView.onDownloadSuccess();

                            break;
                        case MGConstants.DownloadStatus.DOWNLOADING:
                            bannerView.updateProgress(progress);
                            break;
                        case MGConstants.DownloadStatus.FAILED:
                        default:
                            bannerView.onDownloadFailed();
                            Util.toast(getContext(), getString(R.string.download_failed));
                            break;

                    }
                }
            });
        }
    };


    /**
     * Connectivity Receiver
     **/
    private BroadcastReceiver mConnectivityReceiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            if (intent.getAction().equals(ConnectivityManager.CONNECTIVITY_ACTION)) {
                NetworkInfo networkInfo = intent.getParcelableExtra(ConnectivityManager.EXTRA_NETWORK_INFO);
                if (networkInfo != null && networkInfo.getDetailedState() == NetworkInfo.DetailedState.CONNECTED) {
                    Util.toast(context, "Internet ON");
                } else if (networkInfo != null && networkInfo.getDetailedState() == NetworkInfo.DetailedState.DISCONNECTED) {
                    Util.toast(context, "Internet OFF");
                }
            }
        }
    };

//    @Override
//    public void onDestroyView() {
//        if (rootView.getParent() != null) {
//            ((ViewGroup) rootView.getParent()).removeView(rootView);
//        }
//        super.onDestroyView();
//    }

}
