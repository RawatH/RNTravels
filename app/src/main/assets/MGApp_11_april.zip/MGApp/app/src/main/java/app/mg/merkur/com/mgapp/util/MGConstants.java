package app.mg.merkur.com.mgapp.util;

import android.support.annotation.IntDef;
import android.support.annotation.StringDef;

import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;

/**
 * Created by hrawat on 17-01-2018.
 */

public class MGConstants {

    /**
     * Download constants
     */
    @IntDef({DownloadStatus.SUCCESS,
            DownloadStatus.FAILED,
            DownloadStatus.DOWNLOADING,
            DownloadStatus.DOWNLOADED})
    @Retention(RetentionPolicy.SOURCE)
    public @interface DownloadStatus {
        int SUCCESS = 100;
        int FAILED = 101;
        int DOWNLOADING = 102;
        int DOWNLOADED = 103;
    }

    /**
     * Constants misc
     */
    @StringDef({Action.DOWNLOAD,
            Action.CONNECTIVITY})
    @Retention(RetentionPolicy.SOURCE)
    public @interface Action {
        String DOWNLOAD = "download-event";
        String CONNECTIVITY = "android.net.conn.CONNECTIVITY_CHANGE";
    }

    /**
     * Notification ID const for download status in Notification tray
     */
    @IntDef({Notification.ID})
    @Retention(RetentionPolicy.SOURCE)
    public @interface Notification {
        int ID = 112233;
    }

    /**
     * Category type
     */
    @StringDef({Category.VOLATILITY,
            Category.THEMES,
            Category.FEATURES})
    @Retention(RetentionPolicy.SOURCE)
    public @interface Category {
        String VOLATILITY = "Volatility";
        String THEMES = "Themes";
        String FEATURES = "Features";
    }

    /**
     * Catalog Item Type
     */
    @IntDef({CatalogItemType.GAME,
            CatalogItemType.CABINET})
    @Retention(RetentionPolicy.SOURCE)
    public @interface CatalogItemType {
        int CABINET = 0;
        int GAME = 1;
    }

    /**
     * Filter Mode
     */
    @IntDef({FilterQuery.ANY,
            FilterQuery.ALL})
    @Retention(RetentionPolicy.SOURCE)
    public @interface FilterQuery {
        int ANY = 0;
        int ALL = 1;
    }

    /**
     * Filter Type
     */
    @StringDef({Filter.VOLATILITY,
            Filter.THEMES,
            Filter.FEATURES,
            Filter.SUITES})
    @Retention(RetentionPolicy.SOURCE)
    public @interface Filter {
        String VOLATILITY = "Volatility";
        String THEMES = "Themes";
        String FEATURES = "Features";
        String SUITES = "Suites";
    }

    @IntDef({Selection.ON,
            Selection.OFF})
    @Retention(RetentionPolicy.SOURCE)
    public @interface Selection {
        int ON = 0;
        int OFF = 1;
    }

    @IntDef({RequestTag.DOWNLOAD_INFO})
    @Retention(RetentionPolicy.SOURCE)
    public @interface RequestTag {
        int DOWNLOAD_INFO = 0;
    }


}
