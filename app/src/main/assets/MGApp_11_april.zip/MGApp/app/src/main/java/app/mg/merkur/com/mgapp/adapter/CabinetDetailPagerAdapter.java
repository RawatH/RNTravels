package app.mg.merkur.com.mgapp.adapter;

import android.content.Context;
import android.support.annotation.NonNull;
import android.support.v4.view.PagerAdapter;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.ViewFlipper;

import java.io.File;
import java.util.ArrayList;

import app.mg.merkur.com.mgapp.R;
import app.mg.merkur.com.mgapp.manager.AppController;
import app.mg.merkur.com.mgapp.models.catalog.CabinetVO;
import app.mg.merkur.com.mgapp.models.catalog.CatalogItemVO;
import app.mg.merkur.com.mgapp.models.catalog.GameVO;
import app.mg.merkur.com.mgapp.util.MGConstants;
import app.mg.merkur.com.mgapp.util.Util;

/**
 * Created by hrawat on 08-03-2018.
 */

public class CabinetDetailPagerAdapter extends PagerAdapter {

    private Context context;
    private ArrayList dataList;
    private int catalogItemType;

    public CabinetDetailPagerAdapter(Context context, ArrayList dataList, int catalogItemType) {
        this.context = context;
        this.dataList = dataList;
        this.catalogItemType = catalogItemType;
    }


    @Override
    public int getCount() {
        return dataList.size();
    }

    @Override
    public boolean isViewFromObject(@NonNull View view, @NonNull Object object) {
        return view == object;
    }

    public CatalogItemVO getObject(int position){
        return (CatalogItemVO)dataList.get(position);
    }

    @NonNull
    @Override
    public Object instantiateItem(@NonNull ViewGroup container, int position) {
        View itemView = null;
        switch (catalogItemType) {
            case MGConstants.CatalogItemType.CABINET:
                itemView = LayoutInflater.from(context).inflate(R.layout.cabinet_detail, container, false);
                CabinetVO cabinetVO = (CabinetVO) dataList.get(position);
                TextView tv = itemView.findViewById(R.id.cabinetDetailTxt);
                tv.setText(cabinetVO.getBlurb());
                ImageView iv = itemView.findViewById(R.id.cabinetdetailImg);
                String filePath = "catalog" + File.separator + "cabinets" + File.separator + cabinetVO.getId() + ".png";
                Util.loadImage(context, iv, filePath);
                container.addView(itemView);
                break;
            case MGConstants.CatalogItemType.GAME:
                itemView = LayoutInflater.from(context).inflate(R.layout.game_detail, container, false);
                GameVO gameVO = (GameVO) dataList.get(position);

                TextView gameReelsTxt = itemView.findViewById(R.id.gameDetailsReels);
                gameReelsTxt.setText(gameVO.getReels());

                TextView gameLinesTxt = itemView.findViewById(R.id.gameDetailsLines);
                gameLinesTxt.setText(gameVO.getLines());

                TextView gameVolatilityTxt = itemView.findViewById(R.id.gameDetailsVolatility);
                gameVolatilityTxt.setText(AppController.getInstance().getVolatilityByName("VOL" + gameVO.getVolatility()));

                TextView gameAvailableTxt = itemView.findViewById(R.id.gameDetailsAvailable);
                gameAvailableTxt.setText(gameVO.getSw());

                TextView gameIdTxt = itemView.findViewById(R.id.gameDetailsId);
                gameIdTxt.setText(gameVO.getId());

                TextView gameTaglineTxt = itemView.findViewById(R.id.gameDetailTagline);
                gameTaglineTxt.setText(gameVO.getTagLine());

                TextView gameTeamName = itemView.findViewById(R.id.gameDetailTeam);
                gameTeamName.setText(AppController.getInstance().getTeamNameById(gameVO.getTeam()));

                ImageView gameBannerImg = itemView.findViewById(R.id.gameBanner);
                Util.loadImage(context, gameBannerImg, gameVO.getResCompletePath());

                final ImageView playPauseImg = itemView.findViewById(R.id.flipperPlayPause);
                final ViewFlipper galleryFlipper = itemView.findViewById(R.id.gameGalleryFlipper);
                galleryFlipper.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        if(galleryFlipper.isFlipping()){
                            galleryFlipper.stopFlipping();
                            playPauseImg.setVisibility(View.VISIBLE);
                            playPauseImg.setImageResource(R.drawable.ic_play);
                        }else {
                            galleryFlipper.startFlipping();
                            playPauseImg.setVisibility(View.INVISIBLE);
                        }
                    }
                });
                galleryFlipper.performClick();
                Animation in = AnimationUtils.loadAnimation(context, android.R.anim.fade_in);
                galleryFlipper.setInAnimation(in);
                Animation out = AnimationUtils.loadAnimation(context, android.R.anim.fade_out);
                galleryFlipper.setOutAnimation(out);
                ArrayList<File> fileList = Util.getGalleryFiles(context, gameVO.getGalleryPath(), gameVO.getId());

                for (File file : fileList) {
                    ImageView galleryImg = new ImageView(context);
                    galleryImg.setLayoutParams(new FrameLayout.LayoutParams(FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT));
                    Util.loadImage(context, galleryImg, file);
                    galleryFlipper.addView(galleryImg);
                }

                container.addView(itemView);
                break;
        }

        return itemView;
    }

    @Override
    public void destroyItem(ViewGroup container, int position, Object object) {
        container.removeView((LinearLayout) object);
    }

}
