package app.mg.merkur.com.mgapp.models.catalog;

import app.mg.merkur.com.mgapp.manager.AppController;

/**
 * Created by hrawat on 08-03-2018.
 */

public class FilterVO {
    private Object dataObj;
    private boolean isSelected;

    public FilterVO(Object obj) {
        this.dataObj = obj;
    }

    public Object getDataObj() {
        return dataObj;
    }

    public void setDataObj(Object dataObj) {
        this.dataObj = dataObj;
    }

    public boolean isSelected(String category , String val) {
        return AppController.getInstance().getFilterManager().isFilterSelected(category,val);
    }

    public void setSelected(boolean selected) {
        isSelected = selected;
    }

    public void toggleSelection(){
        this.isSelected = !this.isSelected;
    }
}
