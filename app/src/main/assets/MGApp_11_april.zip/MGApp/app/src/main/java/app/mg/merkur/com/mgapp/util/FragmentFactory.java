package app.mg.merkur.com.mgapp.util;

import android.os.Bundle;
import android.support.annotation.IntDef;
import android.support.annotation.StringDef;

import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;

import app.mg.merkur.com.mgapp.component.ui.fragment.BaseFragment;
import app.mg.merkur.com.mgapp.component.ui.fragment.catalog.CatalogItemDetailFragment;
import app.mg.merkur.com.mgapp.component.ui.fragment.catalog.CatalogFragment;
import app.mg.merkur.com.mgapp.component.ui.fragment.FloorPlanFragment;
import app.mg.merkur.com.mgapp.component.ui.fragment.ProductFragment;
import app.mg.merkur.com.mgapp.component.ui.fragment.SmartGuideFragment;

/**
 * Created by hrawat on 01-02-2018.
 */

public class FragmentFactory {

    private static FragmentFactory INSTANCE;

    private FragmentFactory() {
    }

    public static FragmentFactory getInstance() {

        if (INSTANCE == null) {
            INSTANCE = new FragmentFactory();
        }

        return INSTANCE;
    }

    public BaseFragment getFragment(int fragmentId, Bundle bundle) {

        BaseFragment baseFragment;
        switch (fragmentId) {
            case FragmentId.CATALOG_FRG:
                baseFragment = new CatalogFragment();
                break;
            case FragmentId.FLOOR_FRG:
                baseFragment = new FloorPlanFragment();
                break;
            case FragmentId.PRODUCT_FRG:
                baseFragment = new ProductFragment();
                break;
            case FragmentId.GUIDE_FRG:
                baseFragment = new SmartGuideFragment();
                break;
            case FragmentId.CABINET_DETAIL_FRG:
                baseFragment = new CatalogItemDetailFragment();
                break;
            default:
                baseFragment = null;
                break;
        }
        if (baseFragment != null) {
            baseFragment.setFragId(fragmentId);
        }
        if (bundle != null && baseFragment != null) {
            baseFragment.setArguments(bundle);
        }
        return baseFragment;
    }


    @Retention(RetentionPolicy.SOURCE)
    @IntDef({})
    public @interface FragmentId {
        int CATALOG_FRG = 1;
        int FLOOR_FRG = 2;
        int GUIDE_FRG = 3;
        int PRODUCT_FRG = 4;
        int CABINET_DETAIL_FRG = 5;
    }

    @Retention(RetentionPolicy.SOURCE)
    @StringDef({BackstackTag.FRG_CATALOG_TAG,
            BackstackTag.FRG_CATALOG_DETAIL_TAG,
            BackstackTag.FRG_PRODUCT_TAG,
            BackstackTag.FRG_FLOOR_PLAN_TAG,
            BackstackTag.FRG_SMART_GUIDE_TAG})
    public @interface BackstackTag {
        String FRG_CATALOG_TAG = "catalog";
        String FRG_CATALOG_DETAIL_TAG = "catalogDetail";
        String FRG_PRODUCT_TAG = "product";
        String FRG_FLOOR_PLAN_TAG = "floorPlan";
        String FRG_SMART_GUIDE_TAG = "smartGuide";

    }

}
