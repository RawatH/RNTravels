package app.mg.merkur.com.mgapp.models.download;

import android.arch.persistence.room.Entity;
import android.arch.persistence.room.PrimaryKey;

import app.mg.merkur.com.mgapp.util.MGConstants;

/**
 * Created by hrawat on 29-01-2018.
 */

@Entity(tableName = "download_status")
public class DownloadInfoVO {
    @PrimaryKey(autoGenerate = true)
    public int id;
    private int status;
    private String downloadTs;
    private String lastModifiedTs;
    private String contentLength;
    private boolean isAnUpdate;


    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }


    public int getStatus() {
        return status;
    }

    public void setStatus(int status) {
        this.status = status;
    }

    public String getDownloadTs() {
        return downloadTs;
    }

    public void setDownloadTs(String downloadTs) {
        this.downloadTs = downloadTs;
    }

    public String getLastModifiedTs() {
        return lastModifiedTs;
    }

    public void setLastModifiedTs(String lastModifiedTs) {
        this.lastModifiedTs = lastModifiedTs;
    }

    public String getContentLength() {
        return contentLength;
    }

    public void setContentLength(String contentLength) {
        this.contentLength = contentLength;
    }

    public boolean isDownloaded(){
        return status == MGConstants.DownloadStatus.DOWNLOADED;
    }
    public boolean isDownloading(){
        return status == MGConstants.DownloadStatus.DOWNLOADING;
    }

    public boolean isAnUpdate() {
        return isAnUpdate;
    }

    public void setAnUpdate(boolean anUpdate) {
        isAnUpdate = anUpdate;
    }
}
