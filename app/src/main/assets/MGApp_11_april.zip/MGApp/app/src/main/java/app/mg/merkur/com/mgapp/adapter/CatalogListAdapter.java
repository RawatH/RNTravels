package app.mg.merkur.com.mgapp.adapter;

import android.content.Context;
import android.support.annotation.IntDef;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.util.ArrayList;

import app.mg.merkur.com.mgapp.R;
import app.mg.merkur.com.mgapp.manager.AppController;
import app.mg.merkur.com.mgapp.models.catalog.CabinetVO;
import app.mg.merkur.com.mgapp.models.catalog.CatalogItemVO;
import app.mg.merkur.com.mgapp.models.catalog.GameVO;
import app.mg.merkur.com.mgapp.util.Util;

/**
 * Created by hrawat on 01-02-2018.
 */

public class CatalogListAdapter extends RecyclerView.Adapter<RecyclerView.ViewHolder> {

    private ArrayList dataList;
    private Context context;
    private int type;
    private CatalogListener listener;
    private ArrayList backupDataList;

    public CatalogListAdapter(ArrayList dataList, Context context, int type, CatalogListener listener) {
        this.dataList = dataList;
        this.context = context;
        this.type = type;
        this.listener = listener;
        backupDataList = new ArrayList();
        backupDataList.addAll((ArrayList)dataList.clone());
    }

    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view;
        RecyclerView.ViewHolder vh = null;
        switch (viewType) {
            case CatalogType.CABINET:
                view = LayoutInflater.from(parent.getContext()).inflate(R.layout.cabinet_row_item, parent, false);
                vh = new CabinetViewHolder(view);
                break;
            case CatalogType.GAME:
                view = LayoutInflater.from(parent.getContext()).inflate(R.layout.game_row_item, parent, false);
                vh = new GameViewHolder(view);
                break;
            default:
                break;
        }
        return vh;
    }

    @Override
    public void onBindViewHolder(RecyclerView.ViewHolder holder, int position) {
        switch (type) {
            case CatalogType.CABINET:
                final CabinetVO cabinetVO = (CabinetVO) dataList.get(position);
                CabinetViewHolder cabinetViewHolder = (CabinetViewHolder) holder;
                cabinetViewHolder.getNameTV().setText(cabinetVO.getName());
                cabinetViewHolder.getTaglineTV().setText(cabinetVO.getTagLine());
                Util.loadImage(context, cabinetViewHolder.getCabinetIV(), cabinetVO.getResCompletePath());
                cabinetViewHolder.getNameTV().getRootView().setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        listener.onCatalogItemSelected(cabinetVO ,dataList);
                    }
                });
                break;
            case CatalogType.GAME:
                final GameVO gameVO = (GameVO) dataList.get(position);
                GameViewHolder gameViewHolder = (GameViewHolder) holder;
                gameViewHolder.getNameTV().setText(gameVO.getName());
                gameViewHolder.getTaglineTV().setText(gameVO.getTagLine());
                gameViewHolder.getGameLines().setText(gameVO.getLines());
                gameViewHolder.getGameVolatility().setText(gameVO.fetchVolatility());
                Util.loadImage(context, gameViewHolder.getGameIcon(), gameVO.getResCompletePath());
                gameViewHolder.getNameTV().getRootView().setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        listener.onCatalogItemSelected(gameVO , dataList);
                    }
                });
                break;
        }
    }

    @Override
    public int getItemViewType(int position) {
        return type;
    }

    @Override
    public int getItemCount() {
        return dataList.size();
    }

    public static class CabinetViewHolder extends RecyclerView.ViewHolder {

        private TextView cabinetName;
        private ImageView cabinetIcon;
        private TextView cabinetTagline;

        public CabinetViewHolder(View view) {
            super(view);
            cabinetName = view.findViewById(R.id.cabinetName);
            cabinetTagline = view.findViewById(R.id.cabinetTagline);
            cabinetIcon = view.findViewById(R.id.cabinetIcon);
        }

        public ImageView getCabinetIV() {
            return cabinetIcon;
        }

        public TextView getNameTV() {
            return cabinetName;
        }

        public TextView getTaglineTV() {
            return cabinetTagline;
        }


    }

    public static class GameViewHolder extends RecyclerView.ViewHolder {

        private ImageView gameIcon;
        private TextView gameName;
        private TextView gameTagline;
        private TextView gameLines;
        private TextView gameVolatility;

        public GameViewHolder(View view) {
            super(view);
            gameName = view.findViewById(R.id.gameName);
            gameTagline = view.findViewById(R.id.gameTagline);
            gameIcon = view.findViewById(R.id.gameIcon);
            gameLines = view.findViewById(R.id.gameLines);
            gameVolatility = view.findViewById(R.id.gameVolatility);
        }

        public TextView getNameTV() {
            return gameName;
        }

        public TextView getTaglineTV() {
            return gameTagline;
        }

        public ImageView getGameIcon() {
            return gameIcon;
        }

        public TextView getGameLines() {
            return gameLines;
        }

        public TextView getGameName() {
            return gameName;
        }

        public TextView getGameTagline() {
            return gameTagline;
        }

        public TextView getGameVolatility() {
            return gameVolatility;
        }
    }

    @Retention(RetentionPolicy.SOURCE)
    @IntDef({CatalogType.CABINET, CatalogType.GAME})
    public @interface CatalogType {
        int CABINET = 0;
        int GAME = 1;
    }

    public void applySearchFilter(String searchText) {
        ArrayList filteredList = new ArrayList();

        if (searchText.trim().length() > 0) {
            for (Object obj : AppController.getInstance().getCatalogVO().getGameList()) {
                GameVO gameVO = (GameVO) obj;
                if (gameVO.getName().toLowerCase().indexOf(searchText.toLowerCase()) > -1) {
                    filteredList.add(gameVO);
                }
            }
            dataList.clear();
            dataList.addAll(filteredList);
        } else {
            dataList.clear();
            dataList.addAll(backupDataList);
        }

        notifyDataSetChanged();
    }

    public void resetToDefault(ArrayList defaultList) {
        dataList.clear();
        dataList.addAll(backupDataList);
        notifyDataSetChanged();
    }

    public void setList(ArrayList<GameVO> list) {
        this.dataList = list;
        notifyDataSetChanged();
    }

    public interface CatalogListener {
        void onCatalogItemSelected(CatalogItemVO catalogItemVO ,ArrayList dataList);
    }

}
