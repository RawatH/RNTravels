package app.mg.merkur.com.mgapp.component.ui.activity;

import android.support.v7.app.AppCompatActivity;

/**
 * Created by hrawat on 19-01-2018.
 */

public class SplashActivity extends AppCompatActivity {
}
