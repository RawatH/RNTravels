package app.mg.merkur.com.mgapp.component.ui.custom;

import android.app.ProgressDialog;
import android.content.Context;
import android.content.res.Resources;
import android.content.res.TypedArray;
import android.graphics.Color;
import android.graphics.PorterDuff;
import android.graphics.Typeface;
import android.support.annotation.Nullable;
import android.util.AttributeSet;
import android.view.Gravity;
import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.SeekBar;
import android.widget.TextView;

import app.mg.merkur.com.mgapp.R;
import app.mg.merkur.com.mgapp.util.Util;

/**
 * Created by demo on 04/02/18.
 */

public class BannerView extends LinearLayout {
    private Context mContext;
    private TextView bannerTextView;
    private TextView actionTextView;
    private String bannerText;
    private String actionText;
    private LinearLayout progressContainer;
    private LinearLayout closeContainer;
    private ActionListener actionListener;

    public BannerView(Context context) {
        super(context);
    }

    public BannerView(Context context, @Nullable AttributeSet attrs) {
        super(context, attrs);
        this.mContext = context;
        initUI(attrs);
    }

    public void setActionListener(ActionListener listener) {
        this.actionListener = listener;
    }

    private void initUI(AttributeSet attrs) {
        if (attrs != null) {
            TypedArray array = getContext().obtainStyledAttributes(attrs, R.styleable.bannerview_attr);
            bannerText = "";
            actionText = "";
//            String bannerText = array.getString(R.styleable.bannerview_attr_bannerText);
//            String actionText = array.getString(R.styleable.bannerview_attr_actionText);
            int bannerTextColor = array.getColor(R.styleable.bannerview_attr_bannerTextColor, Color.BLACK);
            int actionTextColor = array.getColor(R.styleable.bannerview_attr_actionTextColor, Color.BLACK);

            LinearLayout masterLayout = new LinearLayout(mContext);
            masterLayout.setOrientation(VERTICAL);
            masterLayout.setGravity(Gravity.CENTER);
            LayoutParams masterLayparams = new LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.MATCH_PARENT);
            masterLayout.setLayoutParams(masterLayparams);

            /*****             BANNER TEXT         ******************/
            LayoutParams bannerParam = new LayoutParams(LayoutParams.WRAP_CONTENT, 0);
            bannerParam.weight = 6;
            this.bannerTextView = new TextView(mContext);
            this.bannerTextView.setLayoutParams(bannerParam);
            this.bannerTextView.setText(bannerText);
            this.bannerTextView.setGravity(Gravity.CENTER);
            this.bannerTextView.setTextColor(bannerTextColor);
            masterLayout.addView(this.bannerTextView);

            /*****            ACTION BUTTON : DOWNLOAD , UPDATE      ******************/
            Resources r = getResources();
            float widthPX = r.getDimension(R.dimen.progress_dimen);
            LayoutParams actionParam = new LayoutParams((int) widthPX, 0);
            actionParam.weight = 4;
            this.actionTextView = new TextView(mContext);
            this.actionTextView.setLayoutParams(actionParam);
            this.actionTextView.setText(actionText);
            this.actionTextView.setGravity(Gravity.TOP);
            this.actionTextView.setGravity(Gravity.CENTER);
            this.actionTextView.setTypeface(Typeface.DEFAULT.DEFAULT_BOLD);
            this.actionTextView.setTextColor(actionTextColor);
            masterLayout.addView(this.actionTextView);

            this.actionTextView.setOnClickListener(new OnClickListener() {
                @Override
                public void onClick(View v) {
                    bannerTextView.setText("Downloading...");
                    bannerTextView.invalidate();
                    actionTextView.setVisibility(GONE);
                    updateProgress(0);
                    progressContainer.setVisibility(VISIBLE);
                    actionListener.onActionClicked();
                }
            });

            /*****             Progressbar          ******************/
            int padding = (int) r.getDimension(R.dimen.container_padding);
            progressContainer = new LinearLayout(mContext);
            progressContainer.setOrientation(HORIZONTAL);
            progressContainer.setVisibility(GONE);
            final LayoutParams containerParam = new LayoutParams(LayoutParams.MATCH_PARENT, 0);
            containerParam.weight = 6;

            progressContainer.setLayoutParams(containerParam);

            final LayoutParams progressBarParam = new LayoutParams(0, LayoutParams.MATCH_PARENT);
            progressBarParam.weight = 8;
            ProgressBar progressBar = new ProgressBar(mContext, null, android.R.attr.progressBarStyleHorizontal);
            progressBar.setId(R.id.progressBar);
            progressBar.setLayoutParams(progressBarParam);
            progressBar.setBackgroundColor(Color.TRANSPARENT);
            progressBar.getProgressDrawable().setColorFilter(Color.WHITE, PorterDuff.Mode.SRC_IN);

            progressBar.setPadding(padding * 2, 0, 0, 0);
            progressContainer.addView(progressBar);

            final LayoutParams cancelParam = new LayoutParams(0, LayoutParams.MATCH_PARENT);
            cancelParam.weight = 2;
            TextView cancelBtn = new TextView(mContext);
            cancelBtn.setId(R.id.cancelProgress);
            cancelBtn.setLayoutParams(cancelParam);
            cancelBtn.setText(R.string.cancel);
            cancelBtn.setTextColor(Color.WHITE);
            cancelBtn.setGravity(Gravity.CENTER);
            cancelBtn.setTypeface(Typeface.DEFAULT.DEFAULT_BOLD);
            progressContainer.addView(cancelBtn);

            cancelBtn.setOnClickListener(new OnClickListener() {
                @Override
                public void onClick(View v) {
                    //DOWNLOAD CANCELLED
                    progressContainer.setVisibility(GONE);
                    actionListener.onDownloadCancelled();
                }
            });

            masterLayout.addView(progressContainer);



            /**********       Banner close   ************/
            closeContainer = new LinearLayout(mContext);
            closeContainer.setVisibility(GONE);
            closeContainer.setGravity(Gravity.CENTER);
            final LayoutParams closeContainerParam = new LayoutParams(LayoutParams.MATCH_PARENT, 0);
            closeContainerParam.weight = 6;
            closeContainer.setLayoutParams(closeContainerParam);

            final LayoutParams closeParam = new LayoutParams(LayoutParams.WRAP_CONTENT, LayoutParams.WRAP_CONTENT);
            closeParam.gravity = Gravity.CENTER;
            TextView closeBtn = new TextView(mContext);
            closeBtn.setId(R.id.closeBanner);
            closeBtn.setLayoutParams(closeParam);
            closeBtn.setText(R.string.close);
            closeBtn.setTextColor(Color.WHITE);
            closeBtn.setTypeface(Typeface.DEFAULT.DEFAULT_BOLD);
            closeContainer.addView(closeBtn);

            closeBtn.setOnClickListener(new OnClickListener() {
                @Override
                public void onClick(View v) {
                    setVisibility(GONE);
                }
            });
            masterLayout.addView(closeContainer);

            addView(masterLayout);
            array.recycle();
        }
    }

    public void reloadDownlaodUI(){
        bannerTextView.setText("Downloading...");
        bannerTextView.invalidate();
        actionTextView.setVisibility(GONE);
        updateProgress(0);
        progressContainer.setVisibility(VISIBLE);
    }


    public void updateText(String actionText, String bannerText) {
        updateBannerText(bannerText);
        updateActionText(actionText);
    }

    public void updateBannerText(String bannerText) {
        this.bannerText = bannerText;
        this.bannerTextView.setText(bannerText);
        this.bannerTextView.invalidate();
    }

    public void updateActionText(String actionText) {
        this.actionText = actionText;
        this.actionTextView.setText(actionText);
        actionTextView.setVisibility(VISIBLE);
        this.actionTextView.invalidate();
    }

    public void updateProgress(int progress) {
        ProgressBar progressBar = progressContainer.findViewById(R.id.progressBar);
        progressBar.setProgress(progress);
        progressBar.invalidate();
    }

    /**
     * Download status callbacks
     */
    public void onDownloadFailed() {
        updateBannerText(getResources().getString(R.string.download_failed));
    }

    public void onDownloadSuccess() {
        updateBannerText(getResources().getString(R.string.latest_info));
        progressContainer.setVisibility(GONE);
        closeContainer.setVisibility(VISIBLE);
    }

    /**
     * Banner action interface
     */
    public interface ActionListener {
        void onActionClicked();
        void onDownloadCancelled();
    }


}
