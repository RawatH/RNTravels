package app.mg.merkur.com.mgapp.models.catalog;

import android.os.Parcel;
import android.os.Parcelable;

import java.io.File;
import java.io.Serializable;

/**
 * Created by hrawat on 18-01-2018.
 */

public class CabinetVO extends CatalogItemVO implements Parcelable {
    private String id;
    private String name;
    private String tagLine;
    private String blurb;
    private String resPath;

    public CabinetVO(){}

    // get and set method

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeString(id);
        dest.writeString(name);
        dest.writeString(tagLine);
        dest.writeString(blurb);
        dest.writeString(resPath);
    }

    // Creator
    public static final Parcelable.Creator CREATOR
            = new Parcelable.Creator() {
        public CabinetVO createFromParcel(Parcel in) {
            return new CabinetVO(in);
        }

        public CabinetVO[] newArray(int size) {
            return new CabinetVO[size];
        }
    };

    // "De-parcel object
    public CabinetVO(Parcel in) {
        id = in.readString();
        name = in.readString();
        tagLine = in.readString();
        blurb = in.readString();
        resPath = in.readString();
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getTagLine() {
        return tagLine;
    }

    public void setTagLine(String tagLine) {
        this.tagLine = tagLine;
    }

    public String getBlurb() {
        return blurb;
    }

    public void setBlurb(String blurb) {
        this.blurb = blurb;
    }

    public String getResPath() {
        return resPath;
    }

    public void setResPath(String resPath) {
        this.resPath = resPath;
    }

    public String getResCompletePath() {
        return resPath + File.separator + getId() + ".png";
    }

    @Override
    public boolean equals(Object obj) {
        CabinetVO cabinetVO = (CabinetVO) obj;
        if (cabinetVO.getName().equalsIgnoreCase(this.getName())) {
            return true;
        } else {
            return false;
        }
    }
}
