package app.mg.merkur.com.mgapp.manager;

import java.text.Collator;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Locale;
import java.util.Map;
import java.util.Set;

import app.mg.merkur.com.mgapp.models.catalog.FilterVO;
import app.mg.merkur.com.mgapp.models.catalog.GameVO;
import app.mg.merkur.com.mgapp.models.catalog.SuiteVO;
import app.mg.merkur.com.mgapp.models.catalog.TagVO;
import app.mg.merkur.com.mgapp.util.MGConstants;

/**
 * Created by hrawat on 13-03-2018.
 */

public class FilterManager {

    private static FilterManager filterManager;

    private FilterSetting filterSetting;

    private FilterManager() {
        filterSetting = new FilterSetting();
    }

    public static FilterManager getInstance() {
        if (filterManager == null) {
            filterManager = new FilterManager();
        }
        return filterManager;
    }

    public FilterSetting getFilterSetting() {
        return filterSetting;
    }

    public void toggleFilter(FilterVO filterVO) {
        filterSetting.updateFilter(filterVO);
    }

    public boolean isFilterSelected(String category, String val) {
        return filterSetting.isFilterSelected(category, val);
    }

    public void resetFilter() {
        filterSetting = null;
        filterSetting = new FilterSetting();
    }

    public int getFilterQuery() {
        return filterSetting.getFilterQueryType();
    }

    public void setFilterQuery(int type) {
        filterSetting.setFilterQueryType(type);
    }

    public HashMap<String, HashSet<String>> getFilterMap() {
        return filterSetting.getFilterMap();
    }

    public boolean isAnyFilterSelected() {
        return filterSetting.isAnyFilterSelected();
    }

    public boolean isAllFilterValid(){
        boolean result = false;
        HashMap<String , HashSet<String>> filterMap = getFilterMap();
        if(filterMap.size() > 1){
            return true;
        }

        int filterCount = 0;
        Set<Map.Entry<String,HashSet<String>>> entrySet = filterMap.entrySet();
        Iterator<Map.Entry<String,HashSet<String>>> itr = entrySet.iterator();

        while (itr.hasNext()){
            Map.Entry<String,HashSet<String>> entry = itr.next();
            filterCount += entry.getValue().size();
        }


        return filterCount > 1;
    }

    public ArrayList<GameVO> getFilteredList() {
        return filterSetting.getFilteredGamesList();
    }

    //Comparators
    private Comparator<GameVO> localeComparator = new Comparator<GameVO>() {
        @Override
        public int compare(GameVO objA, GameVO objB) {
            Collator collator = Collator.getInstance(Locale.GERMANY);
            return collator.compare(objA.getName().trim(), objB.getName().trim());
        }
    };


    class FilterSetting {

        private int filterQueryType = MGConstants.FilterQuery.ANY;

        private HashMap<String, HashSet<String>> filterMap;

        private FilterSetting() {
            filterMap = new HashMap<>();
        }

        public int getFilterQueryType() {
            return filterQueryType;
        }

        public void setFilterQueryType(int filterQueryType) {
            this.filterQueryType = filterQueryType;
        }

        public void updateFilter(FilterVO filterVO) {
            switch (getFilterType(filterVO)) {
                case MGConstants.Filter.VOLATILITY:
                    updateFilter(MGConstants.Filter.VOLATILITY, ((TagVO) filterVO.getDataObj()).getName());
                    break;
                case MGConstants.Filter.THEMES:
                    updateFilter(MGConstants.Filter.THEMES, ((TagVO) filterVO.getDataObj()).getName());
                    break;
                case MGConstants.Filter.FEATURES:
                    updateFilter(MGConstants.Filter.FEATURES, ((TagVO) filterVO.getDataObj()).getName());
                    break;
                case MGConstants.Filter.SUITES:
                    updateFilter(MGConstants.Filter.SUITES, ((SuiteVO) filterVO.getDataObj()).getName());
                    break;
            }

        }

        private void updateFilter(String k, String v) {
            HashSet<String> s = filterMap.get(k);
            if (s == null) {
                s = new HashSet<>();
            }
            boolean result = s.add(v);
            //Filter already added
            if (!result) {
                s.remove(v);
            }
            if (s.size() == 0) {
                filterMap.remove(k);
            } else {
                filterMap.put(k, s);
            }
        }

        public boolean isFilterSelected(String c, String v) {
            HashSet<String> s = filterMap.get(c);
            if (s != null) {
                return s.contains(v);
            }
            return false;
        }

        private String getFilterType(FilterVO filterVO) {
            if (filterVO.getDataObj() instanceof SuiteVO) {
                return MGConstants.Filter.SUITES;
            } else if (filterVO.getDataObj() instanceof TagVO) {
                TagVO tagVO = (TagVO) filterVO.getDataObj();
                switch (tagVO.getCategoryName()) {
                    case MGConstants.Filter.VOLATILITY:
                        return MGConstants.Filter.VOLATILITY;
                    case MGConstants.Filter.THEMES:
                        return MGConstants.Filter.THEMES;
                    case MGConstants.Filter.FEATURES:
                        return MGConstants.Filter.FEATURES;
                }
            }

            return null;
        }

        public HashMap<String, HashSet<String>> getFilterMap() {
            return filterMap;
        }

        public boolean isAnyFilterSelected() {
            return filterMap.size() == 0 ? false : true;
        }


        private boolean checkGameForVol(GameVO gameVO) {
            boolean gameVolFlag = true;
            HashSet<String> volSet = filterMap.get(MGConstants.Filter.VOLATILITY);
            if (volSet != null) {
                Iterator itr = volSet.iterator();
                while (itr.hasNext()) {
                    if (gameHasVolatility((String) itr.next(), gameVO)) {
                        if (filterQueryType == MGConstants.FilterQuery.ANY) {
                            return true;
                        }
                    } else {
                        if (filterQueryType == MGConstants.FilterQuery.ALL) {
                            return false;
                        }
                    }
                }
            }
            return filterQueryType == MGConstants.FilterQuery.ANY ? false : gameVolFlag;

        }

        private boolean checkGameForFeature(GameVO gameVO) {
            boolean gameFeatureFlag = true;
            HashSet<String> featureSet = filterMap.get(MGConstants.Filter.FEATURES);
            if (featureSet != null) {
                Iterator itr = featureSet.iterator();
                while (itr.hasNext()) {
                    if (gameHasFeatureTheme((String) itr.next(), gameVO)) {
                        if (filterQueryType == MGConstants.FilterQuery.ANY) {
                            return true;
                        }
                    } else {
                        if (filterQueryType == MGConstants.FilterQuery.ALL) {
                            return false;
                        }
                    }
                }
            }
            return filterQueryType == MGConstants.FilterQuery.ANY ? false : gameFeatureFlag;

        }

        private boolean checkGameForTheme(GameVO gameVO) {
            boolean gameThemeFlag = true;
            HashSet<String> themeSet = filterMap.get(MGConstants.Filter.THEMES);
            if (themeSet != null) {
                Iterator itr = themeSet.iterator();
                while (itr.hasNext()) {
                    if (gameHasFeatureTheme((String) itr.next(), gameVO)) {
                        if (filterQueryType == MGConstants.FilterQuery.ANY) {
                            return true;
                        }
                    } else {
                        if (filterQueryType == MGConstants.FilterQuery.ALL) {
                            return false;
                        }
                    }
                }
            }
            return filterQueryType == MGConstants.FilterQuery.ANY ? false : gameThemeFlag;
        }


        public ArrayList<GameVO> getFilteredGamesList() {

            ArrayList<GameVO> gameList = AppController.getInstance().getCatalogVO().getGameList();
            ArrayList<GameVO> filteredList = new ArrayList<>();
            HashSet<GameVO> filteredSet = new HashSet<>();
            HashMap<String, HashSet<String>> filterMap = AppController.getInstance().getFilterManager().getFilterMap();


            for (GameVO gameVO : gameList) {
                if (filterQueryType == MGConstants.FilterQuery.ANY) {
                    if (checkGameForVol(gameVO) || checkGameForFeature(gameVO) || checkGameForTheme(gameVO)) {
                        filteredSet.add(gameVO);
                    }
                } else {
                    if (checkGameForVol(gameVO) && checkGameForFeature(gameVO) && checkGameForTheme(gameVO)) {
                        filteredSet.add(gameVO);
                    }
                }
            }


            HashSet<String> suiteSet = filterMap.get(MGConstants.Filter.SUITES);
            if (suiteSet != null) {
                HashSet<GameVO> suiteResult = new HashSet<>();
                if (suiteSet != null) {
                    Iterator itr = suiteSet.iterator();
                    while (itr.hasNext()) {
                        String suiteName = (String) itr.next();
                        if (filterQueryType == MGConstants.FilterQuery.ANY) {
                            suiteResult.addAll(AppController.getInstance().getSuiteGames(suiteName));
                        } else {
                            if (suiteResult.size() == 0) {
                                suiteResult.addAll(AppController.getInstance().getSuiteGames(suiteName));
                            } else {
                                suiteResult.retainAll(AppController.getInstance().getSuiteGames(suiteName));
                            }
                        }
                    }
                    if (filterQueryType == MGConstants.FilterQuery.ANY) {
                        filteredSet.addAll(suiteResult);
                    } else {
                        if (filteredSet.size() == 0) {
                            filteredSet.addAll(suiteResult);
                        } else {
                            filteredSet.retainAll(suiteResult);
                        }
                    }
                }
            }

            filteredList.addAll(filteredSet);
            Collections.sort(filteredList, localeComparator);
            return filteredList;
        }

        private boolean gameHasVolatility(String filVol, GameVO gameVO) {
            String gameVol = AppController.getInstance().getVolatilityByName("VOL" + gameVO.getVolatility());
            if (!filVol.equalsIgnoreCase(gameVol)) {
                return false;
            } else {
                return true;
            }
        }

        private boolean gameHasFeatureTheme(String filFeature, GameVO gameVO) {
            String filEmoji = AppController.getInstance().getEmojiForName(filFeature);
            if (gameVO.getEmoji().contains(filEmoji)) {
                return true;
            } else {
                return false;
            }
        }

        private boolean isGamePresentInSuite(String suiteName, GameVO gameVO) {
            return false;
        }


    }


}
