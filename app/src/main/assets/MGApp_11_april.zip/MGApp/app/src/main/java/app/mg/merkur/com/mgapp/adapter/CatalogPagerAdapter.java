package app.mg.merkur.com.mgapp.adapter;

import android.content.Context;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.v4.view.PagerAdapter;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.FrameLayout;

import java.util.ArrayList;

import app.mg.merkur.com.mgapp.R;
import app.mg.merkur.com.mgapp.manager.AppController;
import app.mg.merkur.com.mgapp.manager.FilterManager;
import app.mg.merkur.com.mgapp.models.catalog.CatalogItemVO;
import app.mg.merkur.com.mgapp.models.catalog.CatalogVO;
import app.mg.merkur.com.mgapp.models.catalog.GameVO;
import app.mg.merkur.com.mgapp.util.FragmentFactory;

/**
 * Created by hrawat on 01-02-2018.
 */

public class CatalogPagerAdapter extends PagerAdapter implements TextWatcher ,CatalogListAdapter.CatalogListener {
    private final CatalogVO catalogVO;
    private Context context;
    private ArrayList dataList;
    private ArrayList<String> headerList;
    private AdapterCommunicator adapterCommunicator;
    private CatalogListAdapter currentDisplayedListAdapter;


    public CatalogPagerAdapter(Context context, AdapterCommunicator adapterCommunicator) {
        this.context = context;
        this.catalogVO = AppController.getInstance().getCatalogVO();
        prepareDataSet();
        this.adapterCommunicator = adapterCommunicator;
    }

    private void prepareDataSet() {
        headerList = new ArrayList<>();
        headerList.add("Cabinets");
        headerList.add("Games");
        dataList = new ArrayList();
        dataList.add(AppController.getInstance().getCatalogVO().getCabinetList());
        dataList.add(AppController.getInstance().getCatalogVO().getGameList());
    }


    @Override
    public int getCount() {
        return dataList.size();
    }

    @Override
    public boolean isViewFromObject(@NonNull View view, @NonNull Object object) {
        return view == object;
    }

    @NonNull
    @Override
    public Object instantiateItem(@NonNull ViewGroup container, int position) {
        LayoutInflater layoutInflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        View view = layoutInflater.inflate(R.layout.catalog_display_layout, container, false);
        init(view, position);
        container.addView(view);
        view.setTag("View" + position);
        return view;
    }

    public void renderFilteredList(ArrayList<GameVO> filteredList , View view){
        RecyclerView catalogList = view.findViewById(R.id.catalogList);
        ((CatalogListAdapter)catalogList.getAdapter()).setList(filteredList);
    }

    private void init(View view, int position) {
        RecyclerView catalogList = view.findViewById(R.id.catalogList);
        if(position == CatalogListAdapter.CatalogType.GAME){
            catalogList.addOnScrollListener(new RecyclerView.OnScrollListener(){

                @Override
                public void onScrolled(RecyclerView recyclerView, int dx, int dy) {
                    super.onScrolled(recyclerView, dx, dy);
                    if (!recyclerView.canScrollVertically(1)) {
                        adapterCommunicator.shiftFloatingActionTo(0);
                    }else{
                        adapterCommunicator.shiftFloatingActionTo(1);
                    }
                }

                @Override
                public void onScrollStateChanged(RecyclerView recyclerView, int newState) {
                    super.onScrollStateChanged(recyclerView, newState);
                }

            });
        }
        LinearLayoutManager layoutManager = new LinearLayoutManager(context);
        catalogList.setLayoutManager(layoutManager);
        CatalogListAdapter adapter = new CatalogListAdapter((ArrayList) dataList.get(position), context, position,this);
        catalogList.setAdapter(adapter);
    }

    @Override
    public void destroyItem(ViewGroup container, int position, Object object) {
        container.removeView((FrameLayout) object);
    }

    @Override
    public CharSequence getPageTitle(int position) {
        String title;
        title = headerList.get(position);
        return title;
    }

    public void toggleSearchView(View view) {
        RecyclerView catalogList = view.findViewById(R.id.catalogList);
        currentDisplayedListAdapter = (CatalogListAdapter) catalogList.getAdapter();
        EditText searchTxt = view.findViewById(R.id.searchText);
        switch (searchTxt.getVisibility()) {
            case View.VISIBLE:
                searchTxt.removeTextChangedListener(this);
                searchTxt.setVisibility(View.GONE);
                searchTxt.setText("");
                currentDisplayedListAdapter.resetToDefault(AppController.getInstance().getCatalogVO().getGameList());
                adapterCommunicator.changeSearchImageResource(R.drawable.ic_search);
                break;
            case View.GONE:
                searchTxt.setVisibility(View.VISIBLE);
                searchTxt.requestFocus();
                adapterCommunicator.changeSearchImageResource(R.drawable.ic_close);
                searchTxt.addTextChangedListener(this);
                break;
        }


    }

    //TextWatcher
    @Override
    public void beforeTextChanged(CharSequence s, int start, int count, int after) {
    }

    @Override
    public void onTextChanged(CharSequence s, int start, int before, int count) {
        String filterText = s.toString();
        currentDisplayedListAdapter.applySearchFilter(filterText);
    }

    @Override
    public void afterTextChanged(Editable s) {

    }

    @Override
    public void onCatalogItemSelected(CatalogItemVO catalogItemVO , ArrayList dataList) {
        Bundle bundle = new Bundle();
        bundle.putSerializable("obj", catalogItemVO);
        bundle.putParcelableArrayList("list",dataList);
        adapterCommunicator.loadFrag(FragmentFactory.FragmentId.CABINET_DETAIL_FRG, bundle , true , FragmentFactory.BackstackTag.FRG_CATALOG_DETAIL_TAG);
    }

    public void filterGameList(View view){
        RecyclerView catalogList = view.findViewById(R.id.catalogList);
        currentDisplayedListAdapter = (CatalogListAdapter) catalogList.getAdapter();
        currentDisplayedListAdapter.setList(FilterManager.getInstance().getFilteredList());
    }

    public void resetGameList(View view) {
        RecyclerView catalogList = view.findViewById(R.id.catalogList);
        currentDisplayedListAdapter = (CatalogListAdapter) catalogList.getAdapter();
        currentDisplayedListAdapter.setList(catalogVO.getGameList());
    }

    public interface AdapterCommunicator {
        void changeSearchImageResource(int drawable);
        void shiftFloatingActionTo(int position);
        void loadFrag(int fragId, Bundle bundle ,boolean addToBackstack , String backstackTag);
    }

}
