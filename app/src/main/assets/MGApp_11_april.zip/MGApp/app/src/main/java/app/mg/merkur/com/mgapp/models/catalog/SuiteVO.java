package app.mg.merkur.com.mgapp.models.catalog;

import java.util.ArrayList;
import java.util.StringTokenizer;

/**
 * Created by hrawat on 18-01-2018.
 */

public class SuiteVO {
    private String id;
    private String name;
    private String games;
    private ArrayList<String> gameList;

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getGames() {
        return games;
    }

    public void setGames(String games) {
        this.games = games;
        gameList = new ArrayList<>();
        StringTokenizer st = new StringTokenizer(this.games ,",");
        while (st.hasMoreElements()){
            gameList.add(st.nextToken().trim());
        }
    }

    public int getGameCount() {
        return gameList.size();
    }

    public ArrayList<String> getGameIdList(){
        return (ArrayList<String>)gameList.clone();
    }

    @Override
    protected Object clone() throws CloneNotSupportedException {
        return super.clone();
    }
}
