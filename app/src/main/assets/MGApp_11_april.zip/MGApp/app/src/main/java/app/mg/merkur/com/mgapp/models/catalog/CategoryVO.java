package app.mg.merkur.com.mgapp.models.catalog;

import java.util.ArrayList;

/**
 * Created by hrawat on 29-01-2018.
 */

public class CategoryVO {

    private String name;
    private ArrayList<TagVO> tagList = new ArrayList<>();

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public ArrayList<TagVO> getTagList() {
        return tagList;
    }

    public void setTagList(ArrayList<TagVO> tagList) {
        this.tagList = tagList;
    }

    public TagVO getTagById(String tagId ){
        for(TagVO tagVO : tagList){
          if(tagVO.getId().equalsIgnoreCase(tagId)){
              return tagVO;
          }
        }
        return null;
    }

    public String getEmojiForName(String name){
        for(TagVO tagVO : getTagList()){
            if(tagVO.getName().equalsIgnoreCase(name)){
                return tagVO.getEmoji();
            }
        }
        return null;
    }
}
