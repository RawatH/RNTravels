package app.mg.merkur.com.mgapp.component.ui.fragment;

import android.app.ProgressDialog;
import android.content.Context;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.view.MenuItem;

import com.android.volley.NetworkResponse;
import com.android.volley.VolleyError;

import app.mg.merkur.com.mgapp.component.ui.custom.BannerView;
import app.mg.merkur.com.mgapp.manager.AppController;
import app.mg.merkur.com.mgapp.network.NetworkResponseListener;
import app.mg.merkur.com.mgapp.util.Util;

/**
 * Created by hrawat on 17-01-2018.
 */

public class BaseFragment extends Fragment implements NetworkResponseListener, BannerView.ActionListener {
    public AppController appController;
    public FragmentListener listener;
    public Context context;
    public String title;
    public int fragId;
    private ProgressDialog pd;

    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
        listener = (FragmentListener)context;
        this.context = context;
    }

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        appController = AppController.getInstance();
        pd = new ProgressDialog(context);
        pd.setCanceledOnTouchOutside(false);
    }

    public void showProgress(String msg){
        pd.setMessage(msg);
        pd.show();
    }

    public void dismissProgress(){
        pd.dismiss();
    }

    @Override
    public void onResume() {
        super.onResume();
        listener.onFragmentLoaded(this);
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title){
        this.title = title;
        listener.updateToolbarTitle();
    }

    public int getFragId() {
        return fragId;
    }

    public void setFragId(int fragId) {
        this.fragId = fragId;
    }

    /**
     * Network callback
     * @param data
     * @param requestTag
     */
    @Override
    public void onSuccessResponse(Object data, int requestTag) {

    }

    @Override
    public void onErrorResponse(VolleyError error, int requestTag) {

    }

    @Override
    public void parseNetworkResponse(NetworkResponse response){

    }

    @Override
    public void onActionClicked() {

    }

    @Override
    public void onDownloadCancelled() {

    }

    public interface FragmentListener {
        void toggleFilterView(int visibility);
        void loadFrag(int fragId , Bundle bundle , boolean addToBackStack ,String backstackTag);
        void updateToolbarTitle();
        void onFragmentLoaded(BaseFragment fragment);
        void invalidateMenu();
    }

}
