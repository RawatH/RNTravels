package app.mg.merkur.com.mgapp.component.ui.custom;

import android.content.Context;
import android.content.res.TypedArray;
import android.graphics.Color;
import android.support.annotation.Nullable;
import android.util.AttributeSet;
import android.view.Gravity;
import android.widget.LinearLayout;
import android.widget.TextView;

import app.mg.merkur.com.mgapp.R;

/**
 * Created by hrawat on 18-01-2018.
 */

public class MGTabView extends LinearLayout {

    private Context mContext;
    private TextView labelTitle;
    public MGTabView(Context context) {
        super(context);
    }

    public MGTabView(Context context, @Nullable AttributeSet attrs) {
        super(context, attrs);
        this.mContext = context;
        setUI(attrs);
    }

    public void setUI(AttributeSet attrs) {
        if (attrs != null) {
            TypedArray array = getContext().obtainStyledAttributes(attrs, R.styleable.tabview_attr);

            String textTitle = array.getString(R.styleable.tabview_attr_titleText);

            int imageID = array.getResourceId(R.styleable.tabview_attr_image, R.mipmap.ic_launcher);

            LinearLayout masterLay = new LinearLayout(mContext);
            masterLay.setGravity(Gravity.BOTTOM);
            masterLay.setOrientation(VERTICAL);
            LayoutParams masterLayparams = new LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.WRAP_CONTENT);
            masterLay.setLayoutParams(masterLayparams);

            LayoutParams lblParams = new LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.WRAP_CONTENT);
            this.labelTitle = new TextView(mContext);
            this.labelTitle.setLayoutParams(lblParams);
            if (textTitle != null && !textTitle.isEmpty())
                this.labelTitle.setText(textTitle);

            this.labelTitle.setGravity(Gravity.CENTER);
            this.labelTitle.setTextColor(Color.BLACK);

            setImageTop(labelTitle, imageID);
            masterLay.addView(labelTitle);
            addView(masterLay);
            array.recycle();
        }
    }

    public void setSelected(){
        this.labelTitle.setTextColor(Color.WHITE);
    }
    public void removeSelected(){
        this.labelTitle.setTextColor(Color.BLACK);
    }

    private void setImageTop(TextView lbl, int image) {
        if (image > 0) {
            lbl.setCompoundDrawablesWithIntrinsicBounds(0, image, 0, 0);
            lbl.setCompoundDrawablePadding(10);
        }
    }
}
