package app.mg.merkur.com.mgapp.models.floorplan;

import java.util.ArrayList;
import java.util.List;

import app.mg.merkur.com.mgapp.models.catalog.CategoryVO;

/**
 * Created by hrawat on 30-01-2018.
 */

public class FloorVO {

    private String title;
    private List<FloorObj> floorList = new ArrayList<>();

    public String getTitle() {
        return title;
    }

    public void setTitle(String name) {
        this.title = name;
    }

    public List<FloorObj> getFloorList() {
        return floorList;
    }

    public void setFloorList(List<FloorObj> floorList) {
        this.floorList = floorList;
    }

    public void addLocationToFloorObj(FloorLocationVO floorLocationVO) {
        FloorObj floorObj = getFloorList().get(getFloorList().size() - 1);
        floorObj.getFloorLocationList().add(floorLocationVO);
    }
}
