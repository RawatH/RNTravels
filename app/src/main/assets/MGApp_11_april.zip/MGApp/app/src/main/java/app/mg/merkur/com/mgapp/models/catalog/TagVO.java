package app.mg.merkur.com.mgapp.models.catalog;

/**
 * Created by hrawat on 29-01-2018.
 */

public class TagVO {

    private String id;
    private String emoji;
    private String name;
    private String color;
    private String tintColor;
    private String smaller;
    private String categoryName;

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getEmoji() {
        return emoji;
    }

    public String getColor() {
        return color;
    }

    public void setColor(String color) {
        this.color = color;
    }

    public void setEmoji(String emoji) {
        this.emoji = emoji;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getTintColor() {
        return tintColor;
    }

    public void setTintColor(String tintColor) {
        this.tintColor = tintColor;
    }

    public String isSmaller() {
        return smaller;
    }

    public void setSmaller(String smaller) {
        this.smaller = smaller ;
    }

    public String getCategoryName() {
        return categoryName;
    }

    public void setCategoryName(String categoryName) {
        this.categoryName = categoryName;
    }
}
