package app.mg.merkur.com.mgapp.component.ui.fragment;

/**
 * Created by hrawat on 17-01-2018.
 */

public class FloorPlanFragment extends BaseFragment {
}
