package app.mg.merkur.com.mgapp.util;

import android.animation.Animator;
import android.view.animation.Animation;

/**
 * Created by hrawat on 02-02-2018.
 */

public class AnimationListener implements Animator.AnimatorListener {

    @Override
    public void onAnimationStart(Animator animation) {

    }

    @Override
    public void onAnimationEnd(Animator animation) {

    }

    @Override
    public void onAnimationCancel(Animator animation) {

    }

    @Override
    public void onAnimationRepeat(Animator animation) {

    }
}
