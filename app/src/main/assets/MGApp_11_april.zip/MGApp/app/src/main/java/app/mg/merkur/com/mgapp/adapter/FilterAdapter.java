package app.mg.merkur.com.mgapp.adapter;

import android.content.Context;
import android.graphics.Color;
import android.support.annotation.IntDef;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.TextView;

import java.io.File;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Set;

import app.mg.merkur.com.mgapp.R;
import app.mg.merkur.com.mgapp.manager.AppController;
import app.mg.merkur.com.mgapp.manager.FilterManager;
import app.mg.merkur.com.mgapp.models.catalog.FilterVO;
import app.mg.merkur.com.mgapp.models.catalog.SuiteVO;
import app.mg.merkur.com.mgapp.models.catalog.TagVO;
import app.mg.merkur.com.mgapp.util.MGConstants;
import app.mg.merkur.com.mgapp.util.Util;

/**
 * Created by hrawat on 07-03-2018.
 */

public class FilterAdapter extends RecyclerView.Adapter<RecyclerView.ViewHolder> implements OnClickListener {
    private ArrayList<FilterVO> dataList;
    private Context ctx;
    private LinkedHashMap<String, ArrayList> filterMap;
    private FilterSelectionListener listener;

    public FilterAdapter(Context ctx, LinkedHashMap<String, ArrayList> filterMap, FilterSelectionListener listener) {
        this.ctx = ctx;
        this.filterMap = filterMap;
        this.listener = listener;
        prepareDataList();
    }

    private void prepareDataList() {
        this.dataList = new ArrayList();
        Set<Map.Entry<String, ArrayList>> entrySet = this.filterMap.entrySet();
        Iterator<Map.Entry<String, ArrayList>> iterator = entrySet.iterator();
        while (iterator.hasNext()) {
            Map.Entry<String, ArrayList> entry = iterator.next();
            dataList.add(getFilterVO(entry.getKey()));
            for (Object obj : entry.getValue()) {
                dataList.add(getFilterVO(obj));
            }
        }
    }

    private FilterVO getFilterVO(Object obj) {
        return new FilterVO(obj);
    }

    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view;
        RecyclerView.ViewHolder vh = null;
        switch (viewType) {
            case TYPE.HEADER:
                view = LayoutInflater.from(parent.getContext()).inflate(R.layout.filter_header, parent, false);
                vh = new HeaderViewHolder(view);
                break;
            case TYPE.THEME_FEATURE:
                view = LayoutInflater.from(parent.getContext()).inflate(R.layout.filter_feature_theme_layout, parent, false);
                vh = new TFViewHolder(view);
                break;
            case TYPE.SUITE:
                view = LayoutInflater.from(parent.getContext()).inflate(R.layout.filter_suite_layout, parent, false);
                vh = new SuiteViewHolder(view);
                break;
            case TYPE.VOLATILITY:
                view = LayoutInflater.from(parent.getContext()).inflate(R.layout.filter_volatility_layout, parent, false);
                vh = new VolatileViewHolder(view);
                break;
            default:
                break;
        }
        return vh;
    }

    @Override
    public void onBindViewHolder(RecyclerView.ViewHolder holder, int position) {
        final FilterVO filterVO;
        switch (holder.getItemViewType()) {
            case TYPE.HEADER:
                HeaderViewHolder headerHolder = (HeaderViewHolder) holder;
                filterVO = dataList.get(position);
                headerHolder.getHeaderText().setText((String) filterVO.getDataObj());
                break;
            case TYPE.THEME_FEATURE:
                TFViewHolder tfHolder = (TFViewHolder) holder;
                filterVO = dataList.get(position);
                final TagVO tagVO = (TagVO) filterVO.getDataObj();
                tfHolder.getThemeName().setText(tagVO.getName());
                String filePath = "catalog" + File.separator + "tags" + File.separator + tagVO.getId() + ".png";
                Util.loadImage(ctx, tfHolder.getIcon(), filePath);

                tfHolder.getSelector().setVisibility(AppController.getInstance().getFilterManager().isFilterSelected(tagVO.getCategoryName(), tagVO.getName()) ? View.VISIBLE : View.GONE);
                ((FrameLayout) tfHolder.getSelector().getParent()).setOnClickListener(new OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        toggleFilterSelection(filterVO);
                        listener.onFilterToggled();
                    }
                });
                break;
            case TYPE.SUITE:
                SuiteViewHolder suiteHolder = (SuiteViewHolder) holder;
                filterVO = dataList.get(position);
                final SuiteVO suiteVO = (SuiteVO) filterVO.getDataObj();
                suiteHolder.getGameCount().setText(suiteVO.getGameCount() + " Games");
                suiteHolder.getSuiteName().setText(suiteVO.getName());

                suiteHolder.getSelector().setVisibility(AppController.getInstance().getFilterManager().isFilterSelected(MGConstants.Filter.SUITES, suiteVO.getName()) ? View.VISIBLE : View.GONE);
                ((FrameLayout) suiteHolder.getSelector().getParent()).setOnClickListener(new OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        toggleFilterSelection(filterVO);
                        listener.onFilterToggled();
                    }
                });
                break;
            case TYPE.VOLATILITY:
                VolatileViewHolder volatileViewHolder = (VolatileViewHolder) holder;
                filterVO = dataList.get(position);
                final TagVO volatileVO = (TagVO) filterVO.getDataObj();
                volatileViewHolder.getVolatilityTxt().setText(volatileVO.getName());
                volatileViewHolder.getVolatilityView().setBackgroundColor(Color.parseColor(volatileVO.getColor()));

                volatileViewHolder.getSelector().setVisibility(AppController.getInstance().getFilterManager().isFilterSelected(volatileVO.getCategoryName(), volatileVO.getName()) ? View.VISIBLE : View.GONE);
                ((FrameLayout) volatileViewHolder.getSelector().getParent()).setOnClickListener(new OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        toggleFilterSelection(filterVO);
                        listener.onFilterToggled();
                    }
                });
                break;
        }
    }

    private void toggleFilterSelection(FilterVO filterVO) {
        AppController.getInstance().getFilterManager().toggleFilter(filterVO);
        filterVO.toggleSelection();
        notifyDataSetChanged();
    }

    @Override
    public int getItemCount() {
        return dataList.size();
    }

    @Override
    public int getItemViewType(int position) {
        FilterVO filterVO = dataList.get(position);
        Object dataObj = filterVO.getDataObj();
        if (dataObj instanceof String) {
            return TYPE.HEADER;
        } else if (dataObj instanceof TagVO) {
            TagVO tagVO = (TagVO) filterVO.getDataObj();
            switch (tagVO.getCategoryName()) {
                case "Volatility":
                    return TYPE.VOLATILITY;
                case "Themes":
                case "Features":
                    return TYPE.THEME_FEATURE;
            }
        } else if (dataObj instanceof SuiteVO) {
            return TYPE.SUITE;
        }

        return -1;
    }

    @Override
    public void onClick(View v) {

    }

    public void resetFilter(LinkedHashMap<String, ArrayList> filterMap) {
        AppController.getInstance().getFilterManager().resetFilter();
        this.filterMap = filterMap;
        prepareDataList();
        notifyDataSetChanged();
        listener.onFilterToggled();
    }

    static class SuiteViewHolder extends RecyclerView.ViewHolder {
        private TextView gameCount;
        private TextView suiteName;
        private ImageView selector;

        public SuiteViewHolder(View view) {
            super(view);
            gameCount = view.findViewById(R.id.gameCount);
            suiteName = view.findViewById(R.id.suiteName);
            selector = view.findViewById(R.id.suiteSelector);
        }

        public TextView getGameCount() {
            return gameCount;
        }

        public TextView getSuiteName() {
            return suiteName;
        }

        public ImageView getSelector() {
            return selector;
        }
    }

    static class VolatileViewHolder extends RecyclerView.ViewHolder {
        private ImageView selector;
        private TextView volatilityTxt;
        private View volatilityView;

        public VolatileViewHolder(View view) {
            super(view);
            selector = view.findViewById(R.id.volatilitySelector);
            volatilityTxt = view.findViewById(R.id.volatilityTxt);
            volatilityView = view.findViewById(R.id.volatilityView);
        }

        public ImageView getSelector() {
            return selector;
        }

        public TextView getVolatilityTxt() {
            return volatilityTxt;
        }

        public View getVolatilityView() {
            return volatilityView;
        }
    }

    static class TFViewHolder extends RecyclerView.ViewHolder {
        private ImageView selector;
        private ImageView icon;
        private TextView themeName;

        public TFViewHolder(View view) {
            super(view);
            selector = view.findViewById(R.id.selector);
            icon = view.findViewById(R.id.icon);
            themeName = view.findViewById(R.id.name);
        }

        public ImageView getSelector() {
            return selector;
        }

        public ImageView getIcon() {
            return icon;
        }

        public TextView getThemeName() {
            return themeName;
        }
    }

    static class HeaderViewHolder extends RecyclerView.ViewHolder {
        private TextView headerText;

        public HeaderViewHolder(View view) {
            super(view);
            headerText = view.findViewById(R.id.filterHeader);
        }

        public TextView getHeaderText() {
            return headerText;
        }
    }

    @Retention(RetentionPolicy.SOURCE)
    @IntDef({TYPE.HEADER, TYPE.THEME_FEATURE, TYPE.SUITE, TYPE.VOLATILITY})
    public @interface TYPE {
        int HEADER = 0;
        int THEME_FEATURE = 1;
        int SUITE = 2;
        int VOLATILITY = 3;
    }

    public interface FilterSelectionListener{
        void onFilterToggled();
    }
}
