package app.mg.merkur.com.mgapp.component.ui.fragment.catalog;

import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.view.ViewPager;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import java.util.ArrayList;

import app.mg.merkur.com.mgapp.R;
import app.mg.merkur.com.mgapp.adapter.CabinetDetailPagerAdapter;
import app.mg.merkur.com.mgapp.component.ui.fragment.BaseFragment;
import app.mg.merkur.com.mgapp.manager.AppController;
import app.mg.merkur.com.mgapp.models.catalog.CabinetVO;
import app.mg.merkur.com.mgapp.models.catalog.GameVO;
import app.mg.merkur.com.mgapp.util.MGConstants;

/**
 * Created by hrawat on 08-03-2018.
 */

public class CatalogItemDetailFragment extends BaseFragment implements ViewPager.OnPageChangeListener {

    private ViewPager cabinetPager;
    private Object catalogItemObj;
    private int catalogItemType;
    private CabinetDetailPagerAdapter adapter ;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_catalog_item_detail, null);
        this.catalogItemObj = getArguments().getSerializable("obj");
        if (catalogItemObj instanceof CabinetVO) {
            catalogItemType = MGConstants.CatalogItemType.CABINET;
            setTitle(((CabinetVO) catalogItemObj).getName());
        } else if (catalogItemObj instanceof GameVO) {
            catalogItemType = MGConstants.CatalogItemType.GAME;
            setTitle(((GameVO) catalogItemObj).getName());
        }
        initView(view);
        return view;
    }

    private void initView(View view) {
        cabinetPager = view.findViewById(R.id.layoutPager);
        switch (catalogItemType) {
            case MGConstants.CatalogItemType.CABINET:
                adapter = new CabinetDetailPagerAdapter(context,getArguments().getParcelableArrayList("list"), catalogItemType);
                break;
            case MGConstants.CatalogItemType.GAME:
                adapter = new CabinetDetailPagerAdapter(context, getArguments().getParcelableArrayList("list"), catalogItemType);
                break;

        }
        cabinetPager.setAdapter(adapter);
        cabinetPager.addOnPageChangeListener(this);
        cabinetPager.setCurrentItem(getSelectedCabinetIndex());
    }

    private int getSelectedCabinetIndex() {
        switch (catalogItemType) {
            case MGConstants.CatalogItemType.CABINET:
                CabinetVO cabinetVO = (CabinetVO) catalogItemObj;
                setTitle(cabinetVO.getName());
                if (cabinetVO != null) {
                    ArrayList<CabinetVO> list = AppController.getInstance().getCatalogVO().getCabinetList();

                    for (int idx = 0; idx < list.size(); idx++) {
                        if (list.get(idx).equals(cabinetVO)) {
                            return idx;
                        }
                    }
                }
                break;
            case MGConstants.CatalogItemType.GAME:
                GameVO gameVO = (GameVO) catalogItemObj;
                setTitle(gameVO.getName());
                if (gameVO != null) {
                    ArrayList<GameVO> list = getArguments().getParcelableArrayList("list");

                    for (int idx = 0; idx < list.size(); idx++) {
                        if (list.get(idx).equals(gameVO)) {
                            return idx;
                        }
                    }
                }
                break;
            default:
                return 0;
        }


        return -1;
    }

    //Pager Listener
    @Override
    public void onPageScrolled(int position, float positionOffset, int positionOffsetPixels) {

    }

    @Override
    public void onPageSelected(int position) {
        switch (catalogItemType) {
            case MGConstants.CatalogItemType.CABINET:
                setTitle(((CabinetVO)adapter.getObject(position)).getName());
                break;
            case MGConstants.CatalogItemType.GAME:
                setTitle(((GameVO)adapter.getObject(position)).getName());
                break;
        }
    }

    @Override
    public void onPageScrollStateChanged(int state) {

    }


}
