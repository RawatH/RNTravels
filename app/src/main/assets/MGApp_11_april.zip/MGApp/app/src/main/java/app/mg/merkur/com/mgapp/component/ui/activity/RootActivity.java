package app.mg.merkur.com.mgapp.component.ui.activity;

import android.animation.Animator;
import android.animation.ObjectAnimator;
import android.app.ProgressDialog;
import android.content.res.Configuration;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.support.annotation.NonNull;
import android.support.design.widget.BottomNavigationView;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentTransaction;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.MenuItem;
import android.view.View;
import android.widget.LinearLayout;

import app.mg.merkur.com.mgapp.R;
import app.mg.merkur.com.mgapp.component.ui.fragment.BaseFragment;
import app.mg.merkur.com.mgapp.component.ui.fragment.ProductFragment;
import app.mg.merkur.com.mgapp.component.ui.fragment.catalog.CatalogFragment;
import app.mg.merkur.com.mgapp.component.ui.fragment.catalog.CatalogItemDetailFragment;
import app.mg.merkur.com.mgapp.util.AnimationListener;
import app.mg.merkur.com.mgapp.util.FragmentFactory;
import app.mg.merkur.com.mgapp.util.Util;

public class RootActivity extends AppCompatActivity implements View.OnClickListener, BaseFragment.FragmentListener {

    private LinearLayout tabContainer;
    private BaseFragment loadedFragment;
    private ProgressDialog pd;
    private Handler handler;
    private LinearLayout fragContainer;
    private Toolbar toolbar;
    private BottomNavigationView bottomNavigationView;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_root);
        setSupportActionBar((Toolbar) findViewById(R.id.toolbar));
        init();
        loadFragment(FragmentFactory.FragmentId.CATALOG_FRG, null, true, FragmentFactory.BackstackTag.FRG_CATALOG_TAG);
    }

    @Override
    public void onConfigurationChanged(Configuration newConfig) {
        super.onConfigurationChanged(newConfig);
    }

    private void init() {
        Util.setOrientation(this);
        toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        handler = new Handler();
        fragContainer = findViewById(R.id.container);
        bottomNavigationView = findViewById(R.id.bottom_navigation);
        bottomNavigationView.setOnNavigationItemSelectedListener(navigationListener);
    }

    private BottomNavigationView.OnNavigationItemSelectedListener navigationListener = new BottomNavigationView.OnNavigationItemSelectedListener() {
        @Override
        public boolean onNavigationItemSelected(@NonNull MenuItem item) {
            switch (item.getItemId()) {
                case R.id.catalog:
                    if (!(loadedFragment instanceof CatalogFragment)) {
                        loadFragment(FragmentFactory.FragmentId.CATALOG_FRG, null, true, FragmentFactory.BackstackTag.FRG_CATALOG_TAG);
                    }
                    break;
                case R.id.floorPlan:
                    break;
                case R.id.smartGuide:
                    break;
                case R.id.product:
                    if (!(loadedFragment instanceof ProductFragment)) {
                        loadFragment(FragmentFactory.FragmentId.PRODUCT_FRG, null, true, FragmentFactory.BackstackTag.FRG_PRODUCT_TAG);
                    }
                    break;

            }
            return true;
        }
    };


    private void loadFragment(int fragmentId, Bundle bundle, boolean addToBackstack, String backstackTag) {
        BaseFragment fragment;
        FragmentManager fm = getSupportFragmentManager();
        fragment = (BaseFragment) fm.findFragmentByTag(backstackTag);

        if (fragment == null) {
            fragment = FragmentFactory.getInstance().getFragment(fragmentId, bundle);
            FragmentTransaction ft = fm.beginTransaction();
            ft.setCustomAnimations(R.anim.fade_in, R.anim.fade_out);
            ft.replace(R.id.container, fragment , backstackTag);

            if (addToBackstack) {
                ft.addToBackStack(backstackTag);
            }
            ft.commit();
        }else{
            fm.popBackStackImmediate(backstackTag,0);
        }

    }


    public void updateCurrentFragment(BaseFragment fragment) {
        loadedFragment = fragment;
        if (loadedFragment instanceof CatalogItemDetailFragment) {
            if (getSupportActionBar() != null) {
                getSupportActionBar().setDisplayHomeAsUpEnabled(true);
                getSupportActionBar().setDisplayShowHomeEnabled(true);
            }
        }
    }

    private void performTabMenuAnimation() {
        new Handler().post(new Runnable() {
            @Override
            public void run() {
                int parentHeight = ((LinearLayout) tabContainer.getParent()).getHeight() + tabContainer.getHeight();
                ObjectAnimator oa = ObjectAnimator.ofFloat(tabContainer, View.TRANSLATION_Y, parentHeight, 0);
                oa.setDuration(500);
                oa.addListener(new AnimationListener() {
                    public void onAnimationStart(Animator animation) {
                        tabContainer.setVisibility(View.VISIBLE);
                    }
                });
                oa.start();

            }
        });
    }


    public int[] geTabLocation() {
        return Util.getLocation(tabContainer);
    }

    @Override
    public void onClick(View v) {

    }

    @Override
    public void toggleFilterView(int visibility) {

    }

    @Override
    public void loadFrag(int fragId, Bundle bundle, boolean addToBackStack, String backstackTag) {
        loadFragment(fragId, bundle, addToBackStack, backstackTag);
    }

    @Override
    public void updateToolbarTitle() {
        toolbar.setTitle(loadedFragment.getTitle());
    }


    @Override
    public void onFragmentLoaded(BaseFragment fragment) {
        loadedFragment = fragment;
        switch (loadedFragment.getFragId()) {
            case FragmentFactory.FragmentId.CABINET_DETAIL_FRG:
                if (getSupportActionBar() != null) {
                    getSupportActionBar().setDisplayHomeAsUpEnabled(true);
                    getSupportActionBar().setDisplayShowHomeEnabled(true);
                }
                break;
            case FragmentFactory.FragmentId.CATALOG_FRG:
                if (getSupportActionBar() != null) {
                    getSupportActionBar().setDisplayHomeAsUpEnabled(false);
                    getSupportActionBar().setDisplayShowHomeEnabled(false);
                }
                break;
        }


        updateToolbarTitle();
    }

    @Override
    public void invalidateMenu() {
        invalidateOptionsMenu();
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case android.R.id.home:
                onBackPressed();
                return true;
        }
        return false;
    }

    @Override
    public void onBackPressed() {
        int count = getSupportFragmentManager().getBackStackEntryCount();
        switch (count) {
            case 1:
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
                    super.finishAndRemoveTask();
                } else {
                    finish();
                    System.exit(0);
                }
                break;
            default:
                getSupportFragmentManager().popBackStackImmediate();
                break;
        }
    }
}
