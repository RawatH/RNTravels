package app.mg.merkur.com.mgapp.component.ui.service;

import android.app.IntentService;
import android.app.Notification;
import android.app.PendingIntent;
import android.content.Intent;
import android.os.Bundle;
import android.os.Messenger;
import android.support.annotation.Nullable;
import android.support.v4.app.NotificationCompat;
import android.support.v4.content.LocalBroadcastManager;
import android.util.Log;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;

import app.mg.merkur.com.mgapp.R;
import app.mg.merkur.com.mgapp.component.ui.activity.RootActivity;
import app.mg.merkur.com.mgapp.util.MGConstants;
import app.mg.merkur.com.mgapp.util.Util;
import okhttp3.Credentials;

/**
 * Created by hrawat on 19-01-2018.
 */

public class DownloadService extends IntentService {

    private static boolean IS_DOWNLOADING;
    private Messenger messageHandler;
    private int downloadProgress;
    private boolean stopService;

    public DownloadService() {
        super("zipdownloader");
    }

    @Override
    public int onStartCommand(@Nullable Intent intent, int flags, int startId) {
        return super.onStartCommand(intent, flags, startId);
    }

    public void setMessageHandler(Messenger messageHandler) {
        this.messageHandler = messageHandler;
    }

    @Override
    protected void onHandleIntent(@Nullable Intent intent) {
        Log.d("req_download","-----Request for download----");
        Bundle bundle = intent.getExtras();
        if (bundle != null) {
            IS_DOWNLOADING = true;
            sendNotification("Downloading...");
            messageHandler = bundle.getParcelable("MESSENGER");
            String zipUrl = bundle.getString("zipUrl");
            downloadFile(zipUrl, new File(Util.getZipFilePath(this)));
        }
    }


    private void sendNotification(String msg) {
        Intent notificationIntent = new Intent(this, RootActivity.class);
        PendingIntent pendingIntent = PendingIntent.getActivity(this, 0, notificationIntent, 0);
        String CHANNEL_ID = "my_channel_01";
        Notification notification =
                new NotificationCompat.Builder(this, CHANNEL_ID)
                        .setContentTitle(getString(R.string.app_name))
                        .setContentText(msg)
                        .setSmallIcon(R.drawable.ic_file_download)
                        .setContentIntent(pendingIntent)
                        .setTicker("Initializing app...")
                        .build();

        startForeground(MGConstants.Notification.ID, notification);
    }

    private void downloadFile(String url, File outputFile) {

        try {
            URL u = new URL(url);
            HttpURLConnection urlConnection = (HttpURLConnection) u.openConnection();
            urlConnection.setRequestMethod("GET");
            urlConnection.setDoInput(true);
            urlConnection.setRequestProperty("Authorization", Credentials.basic("merkur", "sun"));
            urlConnection.connect();

            FileOutputStream fileOutput = new FileOutputStream(outputFile);
            InputStream inputStream = urlConnection.getInputStream();

            byte[] buffer = new byte[1024];
            long totalSize = urlConnection.getContentLength();
            long downloadedSize = 0;
            int bufferLength = 0;

            while ((bufferLength = inputStream.read(buffer)) > 0) {
                fileOutput.write(buffer, 0, bufferLength);
                downloadedSize += bufferLength;
                if (bufferLength > 0) {
                    Log.d("download", ((float)(downloadedSize * 100) / totalSize) + "%");
                    Log.d("download", ((downloadedSize * 100) / totalSize) + "%");
                    int progress = (int) ((downloadedSize * 100) / totalSize);
                    sendMessage(progress);
                    if(this.stopService){
                        return;
                    }
                }
            }
            fileOutput.close();
        } catch (FileNotFoundException e) {
            sendMessage(MGConstants.DownloadStatus.FAILED);
            return;
        } catch (IOException e) {
            sendMessage(MGConstants.DownloadStatus.FAILED);
            return;
        } finally {
            stopSelf();
        }
    }

    private void sendMessage(int progress) {
        if (progress > this.downloadProgress) {
            sendNotification(getString(R.string.downloading) + " " + progress + "%");
        }
        this.downloadProgress = progress;
        Intent intent = new Intent(MGConstants.Action.DOWNLOAD);
        intent.putExtra("progress", progress);
        intent.putExtra("downloadStatus", progress == 100 ? MGConstants.DownloadStatus.SUCCESS :MGConstants.DownloadStatus.DOWNLOADING);
        LocalBroadcastManager.getInstance(this).sendBroadcast(intent);
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        this.stopService = true;
        stopSelf();
    }
}
