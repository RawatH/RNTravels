package app.mg.merkur.com.mgapp.db.dao;

import android.arch.persistence.room.Dao;
import android.arch.persistence.room.Delete;
import android.arch.persistence.room.Insert;
import android.arch.persistence.room.Query;
import android.arch.persistence.room.Update;

import java.util.List;

import app.mg.merkur.com.mgapp.models.download.DownloadInfoVO;

/**
 * Created by hrawat on 29-01-2018.
 */

@Dao
public interface DownloadDao {

    @Query("SELECT * FROM download_status")
    List<DownloadInfoVO> getAllDownloadedVO();

    @Query("SELECT * FROM download_status where status = 103 and isAnUpdate = 0 ")
    DownloadInfoVO getDownloadedVO();

    @Query("SELECT * FROM download_status where status = :status")
    DownloadInfoVO getDownloadingVO(int status);

    @Insert
    void insert(DownloadInfoVO downloadInfoVO);

    @Update
    void update(DownloadInfoVO downloadInfoVO);

    @Delete
    void deleteDownloadInfo(DownloadInfoVO downloadInfoVO);


}
