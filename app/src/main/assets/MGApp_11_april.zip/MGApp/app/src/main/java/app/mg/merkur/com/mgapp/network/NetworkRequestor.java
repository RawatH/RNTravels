package app.mg.merkur.com.mgapp.network;

import android.content.Context;

import com.android.volley.AuthFailureError;
import com.android.volley.DefaultRetryPolicy;
import com.android.volley.NetworkResponse;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONObject;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;

import okhttp3.Credentials;

/**
 * Created by hrawat on 06-04-2018.
 */

public class NetworkRequestor {
    private static NetworkRequestor INSTANCE;
    private RequestQueue requestQueue;
    private Context ctx;
    private int requestType;
    private String requestUrl;
    private NetworkResponseListener responseListener;
    private int requestTag;


    private NetworkRequestor() {
    }

    private NetworkRequestor(RequestBuilder builder) {
        getInstance(builder);
    }

    public NetworkRequestor getInstance(RequestBuilder builder) {
        if (INSTANCE == null) {
            INSTANCE = new NetworkRequestor();
        }
        this.requestQueue = getRequestQueue(builder);
        this.ctx = builder.ctx;
        this.requestUrl = builder.requestUrl;
        this.requestType = builder.requestType;
        this.responseListener = builder.responseListener;
        this.requestTag = builder.requestTag;

        return INSTANCE;
    }

    private RequestQueue getRequestQueue(RequestBuilder builder) {
        if (requestQueue == null) {
            requestQueue = Volley.newRequestQueue(builder.ctx.getApplicationContext());
        }
        return requestQueue;
    }

    public void getZipInformation() {
        StringRequest stringRequest = new StringRequest(requestType, requestUrl,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        responseListener.onSuccessResponse(response, requestTag);
                    }
                }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                responseListener.onSuccessResponse(error, requestTag);
            }
        }) {
            @Override
            public Map<String, String> getHeaders() throws AuthFailureError {
                Map<String, String> params = new HashMap<>();
                Set<Map.Entry<String, String>> entrySet = params.entrySet();
                Iterator<Map.Entry<String, String>> itr = entrySet.iterator();
                while (itr.hasNext()) {
                    Map.Entry<String, String> entry = itr.next();
                    params.put(entry.getKey(), entry.getValue());
                }
                params.put("Authorization", Credentials.basic("merkur", "sun"));
                return params;
            }

            @Override
            protected Response<String> parseNetworkResponse(NetworkResponse response) {
                responseListener.parseNetworkResponse(response);
                return super.parseNetworkResponse(response);
            }
        };

        // Add the request to the RequestQueue.
        if (stringRequest != null) {
            stringRequest.setShouldCache(false);
            requestQueue.add(stringRequest);
        }

    }

    public static class RequestBuilder {
        private Context ctx;
        private int requestType;
        private String requestUrl;
        private NetworkResponseListener responseListener;
        private int requestTag;

        public RequestBuilder(Context ctx) {
            this.ctx = ctx;
        }

        public RequestBuilder setRequestType(int requestType) {
            this.requestType = requestType;
            return this;
        }

        public RequestBuilder setRequestUrl(String requestUrl) {
            this.requestUrl = requestUrl;
            return this;
        }

        public RequestBuilder setResponseListener(NetworkResponseListener responseListener) {
            this.responseListener = responseListener;
            return this;
        }

        public RequestBuilder setRequestTag(int requestTag) {
            this.requestTag = requestTag;
            return this;
        }

        public NetworkRequestor build() {
            return new NetworkRequestor(this);
        }


    }


}
