package app.mg.merkur.com.mgapp.manager;

import java.util.ArrayList;

import app.mg.merkur.com.mgapp.db.database.MGAppDatabse;
import app.mg.merkur.com.mgapp.models.catalog.CatalogVO;
import app.mg.merkur.com.mgapp.models.catalog.GameVO;
import app.mg.merkur.com.mgapp.models.catalog.TagVO;
import app.mg.merkur.com.mgapp.models.floorplan.FloorVO;

/**
 * Created by hrawat on 30-01-2018.
 */

public class AppController {
    private MGAppDatabse database;
    private static AppController INSTANCE;
    private FilterManager filterManager;
    private CatalogVO catalogVO;
    private FloorVO floorVO;

    private AppController() {
    }

    public static AppController getInstance() {
        if (INSTANCE == null) {
            INSTANCE = new AppController();
        }
        return INSTANCE;
    }

    public void setDatabase(MGAppDatabse db){
        database = db;
    }

    public  MGAppDatabse getDatabase() {
        return database;
    }

    public CatalogVO getCatalogVO() {
        return catalogVO;
    }

    public void setCatalogVO(CatalogVO catalogVO) {
        this.catalogVO = catalogVO;
    }

    public FloorVO getFloorVO() {
        return floorVO;
    }

    public void setFloorVO(FloorVO floorVO) {
        this.floorVO = floorVO;
    }

    public TagVO getTagForCategory(String catgoryName, String tagId) {
        return getCatalogVO().getTagFromCategory(catgoryName, tagId);
    }

    public String getVolatilityByName(String volName) {
        return getCatalogVO().getVolatilityByName(volName);
    }

    public String getEmojiForName(String name) {
        return getCatalogVO().getEmojiForName(name);
    }

    public ArrayList<GameVO> getSuiteGames(String suiteName) {
        return getCatalogVO().getSuiteGames(suiteName);
    }

    public String getTeamNameById(String teamId) {
        return getCatalogVO().getTeamNameById(teamId);
    }

    public FilterManager getFilterManager() {
        return FilterManager.getInstance();
    }

    //Download
    public boolean isUpdateRequired() {
        return false;
    }

    public boolean isAppInitialized() {
        return database.getDownloadDao().getDownloadedVO() != null ;
    }
}
